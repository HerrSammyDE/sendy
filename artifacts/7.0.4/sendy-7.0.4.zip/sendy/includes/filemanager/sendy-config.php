<?php
	$sendy_filemanager_cwd = getcwd();
	chdir(__DIR__.'/..');
	include('functions.php');
	include('login/auth.php');
	chdir($sendy_filemanager_cwd);
	
	if(isset($_GET['i']) && is_numeric($_GET['i']))
	{
		$app_id = (int)get_app_info('app');
		$_SESSION['sendy_filemanager_app'] = $app_id;
	}
	else if(isset($_SESSION['sendy_filemanager_app']) && is_numeric($_SESSION['sendy_filemanager_app']))
		$app_id = (int)$_SESSION['sendy_filemanager_app'];
	else exit;
	
	if(!isset($_GET['dl']))
	{
		ob_start(function($buffer) use ($app_id) {
			return str_replace('?p=', '?i='.$app_id.'&p=', $buffer);
		});
	}
	
	if(!defined('FM_EMBED')) define('FM_EMBED', true);
	
	if(get_app_info('is_sub_user') && $app_id != (int)get_app_info('restricted_to_app'))
		exit;
	
	$q = 'SELECT id FROM apps WHERE id = '.$app_id.' AND userID = '.get_app_info('main_userID').' LIMIT 1';
	$r = mysqli_query($mysqli, $q);
	if(!$r || mysqli_num_rows($r) == 0)
		exit;
	
	$uploads_root = realpath(__DIR__.'/../../uploads');
	if($uploads_root === false)
	{
		mkdir(__DIR__.'/../../uploads', 0777, true);
		$uploads_root = realpath(__DIR__.'/../../uploads');
	}
	
	$root_path = sendy_uploads_path($app_id, '', $uploads_root, true);
	if(!is_writable($root_path))
		@chmod($root_path, 0777);

	$allowed_upload_extensions = '';
	$q = 'SELECT allowed_attachments FROM apps WHERE id = '.$app_id.' AND userID = '.get_app_info('main_userID').' LIMIT 1';
	$r = mysqli_query($mysqli, $q);
	if($r && mysqli_num_rows($r) > 0)
	{
		while($row = mysqli_fetch_array($r))
		{
			$allowed_upload_extensions = strtolower(trim($row['allowed_attachments']));
			$allowed_upload_extensions = preg_replace('/\s+/', '', $allowed_upload_extensions);
			$allowed_upload_extensions = trim($allowed_upload_extensions, '.');
		}
	}
	if($allowed_upload_extensions=='')
		$allowed_upload_extensions = '__no_uploads__';
	
	$app_path = parse_url(get_app_info('path'), PHP_URL_PATH);
	$app_path = $app_path === null ? '' : trim($app_path, '/');
	$root_url = ($app_path == '' ? '' : $app_path.'/').'uploads/'.$app_id;
	$fm_self_url = rtrim(get_app_info('path'), '/').'/includes/filemanager/tinyfilemanager.php';
	if(!defined('FM_SELF_URL')) define('FM_SELF_URL', $fm_self_url);
	
	$use_auth = false;
	$global_readonly = false;
	$allowed_file_extensions = 'gif,png,jpg,jpeg,webp,svg,pdf,txt,csv,html,htm,css,js,json,zip';
	$exclude_items = array('*.php', '.htaccess');
	$path_display_mode = 'relative';
	$online_viewer = false;
	$edit_files = false;
	$use_highlightjs = false;
	$sticky_navbar = false;
	$default_timezone = get_app_info('timezone') == '' ? 'Etc/UTC' : get_app_info('timezone');
	$CONFIG = '{"lang":"en","error_reporting":false,"show_hidden":false,"hide_Cols":false,"theme":"'.(get_app_info('dark_mode') ? 'dark' : 'light').'"}';
?>
