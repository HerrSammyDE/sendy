<?php
	$file_manager_url = get_app_info('path').'/includes/filemanager/tinyfilemanager.php?i='.get_app_info('app').'&p=';
?>
<?php if(!defined('SENDY_FILE_MANAGER_BUTTON_ASSETS')): define('SENDY_FILE_MANAGER_BUTTON_ASSETS', true); ?>
<script type="text/javascript" src="<?php echo get_app_info('path')?>/js/fancybox/jquery.fancybox.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo get_app_info('path')?>/js/fancybox/jquery.fancybox.css" media="screen" />
<style type="text/css">
	.sendy-file-manager-btn {
		border-radius: 5px;
		height: 18px;
		margin-left: 8px;
		vertical-align: top;
	}
	.sendy-file-manager-btn .sendy-file-manager-btn-text {
		position: relative;
		top: -2px;
	}
</style>
<script type="text/javascript">
	$(document).ready(function() {
		$(".sendy-file-manager-btn").click(function(e) {
			e.preventDefault();
			
			$.fancybox.open({
				src : $(this).attr("href"),
				type : 'iframe',
				padding : 0,
				iframe : {
					preload : false
				}
			});
		});
	});
</script>
<?php endif; ?>
<a href="<?php echo $file_manager_url;?>" class="btn sendy-file-manager-btn pull-left"><i class="icon-folder-open"></i> <span class="sendy-file-manager-btn-text"><?php echo _('Files');?></span></a>
