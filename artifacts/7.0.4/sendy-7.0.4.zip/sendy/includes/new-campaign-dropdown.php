<?php
include_once(dirname(__FILE__).'/helpers/ai-email-prompt.php');

if(!function_exists('sendy_get_new_campaign_dropdown_templates'))
{
	function sendy_get_new_campaign_dropdown_templates()
	{
		static $templates = null;
		global $mysqli;
		
		if($templates !== null) return $templates;
		
		$templates = array();
		$q = 'SELECT id, template_name FROM template WHERE app = '.(int)get_app_info('app').' AND userID = '.(int)get_app_info('main_userID').' ORDER BY id DESC';
		$r = mysqli_query($mysqli, $q);
		
		if($r && mysqli_num_rows($r) > 0)
		{
		    while($row = mysqli_fetch_assoc($r))
		    {
				$templates[] = array(
					'id' => (int)$row['id'],
					'template_name' => stripslashes($row['template_name'])
				);
		    }
		}
		
		return $templates;
	}
}

if(!function_exists('sendy_render_new_campaign_dropdown_menu'))
{
	function sendy_render_new_campaign_dropdown_menu($menu_class='dropdown-menu', $options=array())
	{
		$defaults = array(
			'header_label' => _('New campaign'),
			'create_label' => _('Create a new campaign'),
			'create_url' => get_app_info('path').'/create?i='.get_app_info('app'),
			'create_icon_html' => '<i class="icon-edit"></i> ',
			'show_import_html' => true,
			'show_import_url' => true,
			'show_create_with_ai' => true,
			'import_html_link_class' => 'new-campaign-import-link',
			'import_url_modal_id' => 'new-campaign-url-import-modal',
			'ai_modal_id' => 'new-campaign-ai-modal',
			'show_templates' => true,
			'template_header_label' => _('Or use a template'),
			'template_url_format' => get_app_info('path').'/includes/templates/use-template.php?i='.get_app_info('app').'&t=%d',
			'menu_style' => ''
		);
		
		foreach($defaults as $key => $value)
		{
			if(!isset($options[$key])) $options[$key] = $value;
		}
		
		$templates = sendy_get_new_campaign_dropdown_templates();
		$ai_addon_enabled = sendy_ai_addon_enabled();
		$ai_disabled = sendy_brand_ai_disabled();
		$ai_modal_id = $ai_addon_enabled ? $options['ai_modal_id'] : 'sendy-ai-paywall-modal';
		?>
		<ul class="<?php echo $menu_class;?>"<?php if($options['menu_style']!=''){echo ' style="'.htmlspecialchars($options['menu_style'], ENT_QUOTES, 'UTF-8').'"';}?>>
			<li class="dropdown-header"><?php echo $options['header_label'];?></li>
			<li><a href="<?php echo $options['create_url'];?>"><?php echo $options['create_icon_html'].$options['create_label'];?></a></li>
			<?php if($options['show_create_with_ai'] && !$ai_disabled):?>
				<li><a href="#<?php echo htmlspecialchars($ai_modal_id, ENT_QUOTES, 'UTF-8');?>" data-toggle="modal" data-sendy-ai-demo="create-with-ai" class="sendy-create-with-ai-link"><i class="icon-magic"></i> <span class="sendy-create-with-ai-text"><?php echo _('Create with AI');?></span></a></li>
			<?php endif;?>
			<?php if($options['show_import_html']):?>
				<li><a href="javascript:void(0)" class="<?php echo htmlspecialchars($options['import_html_link_class'], ENT_QUOTES, 'UTF-8');?>"><i class="icon-file-text"></i> <?php echo _('Import HTML file');?></a></li>
			<?php endif;?>
			<?php if($options['show_import_url']):?>
				<li><a href="#<?php echo htmlspecialchars($options['import_url_modal_id'], ENT_QUOTES, 'UTF-8');?>" data-toggle="modal"><i class="icon-link"></i> <?php echo _('Import from URL');?></a></li>
			<?php endif;?>
			<?php if($options['show_templates'] && count($templates) > 0):?>
				<li class="divider"></li>
				<li class="dropdown-header"><?php echo $options['template_header_label'];?></li>
				<?php foreach($templates as $template):?>
					<li><a href="<?php echo sprintf($options['template_url_format'], $template['id']);?>"><?php echo htmlspecialchars($template['template_name'], ENT_QUOTES, 'UTF-8');?></a></li>
				<?php endforeach;?>
			<?php endif;?>
		</ul>
		<?php
	}
}

if(!function_exists('sendy_get_new_template_dropdown_options'))
{
	function sendy_get_new_template_dropdown_options()
	{
		return array(
			'header_label' => _('New template'),
			'create_label' => _('Create a new template'),
			'create_url' => get_app_info('path').'/create-template?i='.get_app_info('app'),
			'show_templates' => false,
			'import_html_link_class' => 'new-template-import-link',
			'import_url_modal_id' => 'new-template-url-import-modal',
			'ai_modal_id' => 'new-template-ai-modal'
		);
	}
}

if(!function_exists('sendy_get_new_template_dropdown_support_options'))
{
	function sendy_get_new_template_dropdown_support_options()
	{
		return array(
			'support_key' => 'new-template',
			'import_html_link_class' => 'new-template-import-link',
			'html_upload_form_id' => 'new-template-html-upload-form',
			'import_file_input_id' => 'new-template-import-btn',
			'html_hidden_fields' => array('aid' => get_app_info('app'), 'is_template' => 1),
			'url_modal_id' => 'new-template-url-import-modal',
			'url_form_id' => 'template-url-import-form',
			'url_input_id' => 'template-url-import-value',
			'url_hidden_fields' => array('aid' => get_app_info('app'), 'is_template' => 1),
			'ai_modal_id' => 'new-template-ai-modal',
			'ai_form_id' => 'new-template-ai-form',
			'ai_task_input_id' => 'new-template-ai-task',
			'ai_look_feel_input_id' => 'new-template-ai-look-feel',
			'ai_requirements_input_id' => 'new-template-ai-requirements',
			'ai_hidden_fields' => array('aid' => get_app_info('app'), 'is_template' => 1)
		);
	}
}

if(!function_exists('sendy_render_new_campaign_dropdown_hidden_fields'))
{
	function sendy_render_new_campaign_dropdown_hidden_fields($fields)
	{
		foreach($fields as $name => $value)
		{
			echo '<input type="hidden" name="'.htmlspecialchars($name, ENT_QUOTES, 'UTF-8').'" value="'.htmlspecialchars($value, ENT_QUOTES, 'UTF-8').'" />';
		}
	}
}

if(!function_exists('sendy_render_new_campaign_dropdown_support'))
{
	function sendy_render_new_campaign_dropdown_support($options=array())
	{
		static $rendered = array();
		
		$defaults = array(
			'support_key' => 'new-campaign',
			'import_html_link_class' => 'new-campaign-import-link',
			'html_upload_form_id' => 'new-campaign-html-upload-form',
			'import_file_input_id' => 'new-campaign-import-btn',
			'html_upload_action' => get_app_info('path').'/includes/create/import-html.php',
			'html_hidden_fields' => array('aid' => get_app_info('app')),
			'url_modal_id' => 'new-campaign-url-import-modal',
			'url_form_id' => 'url-import-form',
			'url_form_action' => get_app_info('path').'/includes/create/import-url.php',
			'url_input_id' => 'url-import-value',
			'url_hidden_fields' => array('aid' => get_app_info('app')),
			'ai_modal_id' => 'new-campaign-ai-modal',
			'ai_form_id' => 'new-campaign-ai-form',
			'ai_form_action' => get_app_info('path').'/includes/create/create-with-ai.php',
			'ai_task_input_id' => 'new-campaign-ai-task',
			'ai_look_feel_input_id' => 'new-campaign-ai-look-feel',
			'ai_requirements_input_id' => 'new-campaign-ai-requirements',
			'ai_hidden_fields' => array('aid' => get_app_info('app'))
		);
		
		foreach($defaults as $key => $value)
		{
			if(!isset($options[$key])) $options[$key] = $value;
		}
		
		if(isset($rendered[$options['support_key']])) return;
		$rendered[$options['support_key']] = true;
		$ai_addon_enabled = sendy_ai_addon_enabled();
		$ai_disabled = sendy_brand_ai_disabled();
	?>
		<style type="text/css">
			@keyframes sendyAiRainbowPulse {
				0% { background-position: 0% 50%; }
				100% { background-position: 200% 50%; }
			}
			.sendy-create-with-ai-link,
			.dropdown-menu > li > a.sendy-create-with-ai-link:hover,
			.dropdown-menu > li > a.sendy-create-with-ai-link:focus {
				color: #993FED !important;
				font-weight: bold;
			}
			.sendy-create-with-ai-text {
				animation: sendyAiRainbowPulse 2s linear infinite;
				background-image: linear-gradient(90deg, #993FED 0%, #007bff 18%, #16a34a 36%, #f59e0b 54%, #ef4444 72%, #993FED 90%, #007bff 100%) !important;
				background-size: 200% 100% !important;
				background-position: 0% 50%;
				-webkit-background-clip: text !important;
				background-clip: text !important;
				color: #993FED !important;
				-webkit-text-fill-color: transparent !important;
				display: inline-block;
				font-weight: bold;
			}
			.dropdown-menu > li > a.sendy-create-with-ai-link:hover .sendy-create-with-ai-text,
			.dropdown-menu > li > a.sendy-create-with-ai-link:focus .sendy-create-with-ai-text {
				background-image: linear-gradient(90deg, #993FED 0%, #007bff 18%, #16a34a 36%, #f59e0b 54%, #ef4444 72%, #993FED 90%, #007bff 100%) !important;
				-webkit-background-clip: text !important;
				background-clip: text !important;
				color: #993FED !important;
				-webkit-text-fill-color: transparent !important;
			}
		</style>

		<form action="<?php echo $options['html_upload_action'];?>" method="POST" accept-charset="utf-8" enctype="multipart/form-data" id="<?php echo htmlspecialchars($options['html_upload_form_id'], ENT_QUOTES, 'UTF-8');?>" style="display:none;">
			<input id="<?php echo htmlspecialchars($options['import_file_input_id'], ENT_QUOTES, 'UTF-8');?>" name="html-file" type="file" style="display:none;"/>
			<?php sendy_render_new_campaign_dropdown_hidden_fields($options['html_hidden_fields']);?>
		</form>
		
		<script type="text/javascript">
			$(document).ready(function() {
				var $newCampaignModal = $("#<?php echo addslashes($options['url_modal_id']);?>");
				var $newCampaignAiModal = $("#<?php echo addslashes($ai_addon_enabled ? $options['ai_modal_id'] : 'sendy-ai-paywall-modal');?>");
				var $newCampaignUploadForm = $("#<?php echo addslashes($options['html_upload_form_id']);?>");
				
				if($newCampaignModal.parent().length && !$newCampaignModal.parent().is("body"))
				{
					$newCampaignModal.appendTo("body");
				}
				
				if($newCampaignUploadForm.parent().length && !$newCampaignUploadForm.parent().is("body"))
				{
					$newCampaignUploadForm.appendTo("body");
				}

				if($newCampaignAiModal.parent().length && !$newCampaignAiModal.parent().is("body"))
				{
					$newCampaignAiModal.appendTo("body");
				}
				
				$(".<?php echo addslashes($options['import_html_link_class']);?>").click(function(e){
					e.preventDefault();
					$("#<?php echo addslashes($options['import_file_input_id']);?>:hidden").trigger('click');
				});
				$("#<?php echo addslashes($options['import_file_input_id']);?>").change(function(){
					$("#<?php echo addslashes($options['html_upload_form_id']);?>").submit();
				});
				$("#<?php echo addslashes($options['ai_form_id']);?>").submit(function(){
					var formId = "<?php echo addslashes($options['ai_form_id']);?>";
					var $button = $("button[type='submit'][form='" + formId + "'], #" + formId + " button[type='submit']");
					$button.prop("disabled", true).html('<i class="icon-time"></i> <span class="sendy-create-with-ai-text"><?php echo addslashes(_('Generating..'));?></span>');
				});
			});
		</script>
		
		<div id="<?php echo htmlspecialchars($options['url_modal_id'], ENT_QUOTES, 'UTF-8');?>" class="modal hide fade">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h3><?php echo _('Import from URL');?></h3>
			</div>
			<div class="modal-body">
				<form action="<?php echo $options['url_form_action'];?>" method="POST" accept-charset="utf-8" class="form-vertical" name="<?php echo htmlspecialchars($options['url_form_id'], ENT_QUOTES, 'UTF-8');?>" id="<?php echo htmlspecialchars($options['url_form_id'], ENT_QUOTES, 'UTF-8');?>">
					<label class="control-label" for="<?php echo htmlspecialchars($options['url_input_id'], ENT_QUOTES, 'UTF-8');?>"><?php echo _('URL of the email you want to import');?></label>
					<div class="control-group">
						<div class="controls">
					  	<input type="text" class="input-xlarge" id="<?php echo htmlspecialchars($options['url_input_id'], ENT_QUOTES, 'UTF-8');?>" name="url-import-value" placeholder="<?php echo _('eg. https://mydomain.com/email.html');?>">
						</div>
					</div>
					<?php sendy_render_new_campaign_dropdown_hidden_fields($options['url_hidden_fields']);?>
					<button type="submit" class="btn"><i class="icon-plus-sign"></i> <?php echo _('Import');?></button>
				</form>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn btn-inverse" data-dismiss="modal"><i class="icon icon-ok-sign"></i> <?php echo _('Close');?></a>
			</div>
		</div>

		<?php if(!$ai_disabled && $ai_addon_enabled):?>
				<div id="<?php echo htmlspecialchars($options['ai_modal_id'], ENT_QUOTES, 'UTF-8');?>" class="modal hide fade">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h3><?php echo _('Create with AI');?></h3>
					</div>
					<div class="modal-body">
						<form action="<?php echo $options['ai_form_action'];?>" method="POST" accept-charset="utf-8" class="form-vertical" name="<?php echo htmlspecialchars($options['ai_form_id'], ENT_QUOTES, 'UTF-8');?>" id="<?php echo htmlspecialchars($options['ai_form_id'], ENT_QUOTES, 'UTF-8');?>">
							<label class="control-label" for="<?php echo htmlspecialchars($options['ai_task_input_id'], ENT_QUOTES, 'UTF-8');?>"><?php echo _('Task');?></label>
							<div class="control-group">
								<div class="controls">
									<textarea class="input-xlarge" id="<?php echo htmlspecialchars($options['ai_task_input_id'], ENT_QUOTES, 'UTF-8');?>" name="ai-task" rows="3" style="width: 95%; height: 70px !important; min-height: 70px !important;"><?php echo htmlspecialchars(sendy_get_ai_email_prompt_task(), ENT_QUOTES, 'UTF-8');?></textarea>
								</div>
							</div>
							<label class="control-label" for="<?php echo htmlspecialchars($options['ai_look_feel_input_id'], ENT_QUOTES, 'UTF-8');?>"><?php echo _('Design and content');?></label>
							<div class="control-group">
								<div class="controls">
									<textarea class="input-xlarge" id="<?php echo htmlspecialchars($options['ai_look_feel_input_id'], ENT_QUOTES, 'UTF-8');?>" name="ai-look-feel" rows="9" style="width: 95%; height: 140px !important;"><?php echo htmlspecialchars(sendy_get_ai_email_prompt_look_feel(), ENT_QUOTES, 'UTF-8');?></textarea>
								</div>
							</div>
							<label class="control-label" for="<?php echo htmlspecialchars($options['ai_requirements_input_id'], ENT_QUOTES, 'UTF-8');?>"><?php echo _('Requirements');?></label>
							<div class="control-group">
								<div class="controls">
									<textarea class="input-xlarge" id="<?php echo htmlspecialchars($options['ai_requirements_input_id'], ENT_QUOTES, 'UTF-8');?>" name="ai-requirements" rows="10" style="width: 95%; height: 70px !important; min-height: 70px !important;"><?php echo htmlspecialchars(sendy_get_ai_email_prompt_requirements(), ENT_QUOTES, 'UTF-8');?></textarea>
								</div>
							</div>
							<?php sendy_render_new_campaign_dropdown_hidden_fields($options['ai_hidden_fields']);?>
						</form>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary" form="<?php echo htmlspecialchars($options['ai_form_id'], ENT_QUOTES, 'UTF-8');?>"><i class="icon-magic"></i> <?php echo _('Generate email');?></button>
					</div>
				</div>
		<?php elseif(!$ai_disabled):?>
				<?php
					if(!isset($rendered['sendy-ai-paywall-modal']))
					{
						$rendered['sendy-ai-paywall-modal'] = true;
						echo sendy_ai_paywall_modal_html();
					}
				?>
		<?php endif;?>
		<?php
		}
	}
