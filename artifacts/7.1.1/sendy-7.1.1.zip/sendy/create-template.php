<?php include('includes/header.php');?>
<?php include('includes/login/auth.php');?>
<?php include('includes/templates/main.php');?>
<?php 
	//IDs
	$aid = isset($_GET['i']) && is_numeric($_GET['i']) ? get_app_info('app') : exit;
	
	if(get_app_info('is_sub_user')) 
	{
		if(get_app_info('app')!=get_app_info('restricted_to_app'))
		{
			echo '<script type="text/javascript">window.location="'.addslashes(get_app_info('path')).'/templates?i='.get_app_info('restricted_to_app').'"</script>';
			exit;
		}
	}
?>

<script src="<?php echo get_app_info('path');?>/js/create/editor-modes.js?18"></script>
<script src="<?php echo get_app_info('path');?>/js/ai-subject-generator.js?2"></script>
<?php
	$dark_mode = get_app_info('dark_mode');
	$editor_mode = 'dragdrop';
	$grapesjs_initial_html = '';
	$grapesjs_project_data = '';
	$grapesjs_save_only_selector = '';
	include('js/create/grapesjs-editor.php');
?>

<!-- Validation -->
<script type="text/javascript" src="<?php echo get_app_info('path');?>/js/validate.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$("#edit-form").validate({
			rules: {
				template_name: {
					required: true	
				},
				html: {
					required: true
				}
			},
			messages: {
				template_name: "<?php echo addslashes(_('The name of this template is required'));?>",
				html: "<?php echo addslashes(_('Your HTML code is required'));?>"
			}
		});
		SendyEditorModes.initSwitcher({
			formSelector: '#edit-form',
			modeButtonSelector: '.editor-mode-toggle',
			requiredFieldSelector: '#template_name',
			requiredFieldFallback: '<?php echo addslashes(_('Untitled'));?>',
			htmlSelector: '#html'
		});
		$("#template_name").focus();
	});
</script>

<div class="row-fluid">
    <div class="span2">
        <?php include('includes/sidebar.php');?>
    </div> 
    
    <div class="span10">
	    <div class="row-fluid">
		    <div class="span10">
			    <div>
			    	<p class="lead">
	    	<?php echo sendy_brand_logo_img();?>
		    	<?php if(get_app_info('is_sub_user')):?>
			    	<?php echo get_app_data('app_name');?>
		    	<?php else:?>
			    	<a href="<?php echo get_app_info('path'); ?>/edit-brand?i=<?php echo get_app_info('app');?>" data-placement="right" title="<?php echo _('Edit brand settings');?>"><?php echo get_app_data('app_name');?> <span class="icon icon-pencil top-brand-pencil"></span></a>
		    	<?php endif;?>
		    </p>
		    	</div>
		    	<h2><?php echo _('Create template');?></h2><br/>
		    </div>
	    </div>
	    
	    <div class="row-fluid">
		    		    
	    	<form action="<?php echo get_app_info('path')?>/includes/templates/save-template.php?i=<?php echo get_app_info('app')?>" method="POST" accept-charset="utf-8" class="form-vertical" id="edit-form">
		    	
		    	<div class="span3">
			        <label class="control-label" for="template_name"><?php echo _('Template name');?></label>
			    	<div class="control-group">
				    	<div class="controls">
			              <input type="text" class="input-xlarge" id="template_name" name="template_name" placeholder="<?php echo _('Name of this template');?>">
			            </div>
			        </div>
			        <?php
			        	$ai_subject_target_selector = '#template_name';
			        	include('includes/helpers/ai-subject-generator.php');
			        ?>
					
					<label class="control-label" for="from_name" style="clear:both;"><?php echo _('From name');?></label>
					<div class="control-group">
						<div class="controls">
						  <input type="text" class="input-xlarge" id="from_name" name="from_name" placeholder="<?php echo _('From name');?>" value="<?php echo get_app_data('from_name');?>">
						</div>
					</div>
					
					<label class="control-label" for="from_email"><?php echo _('From email');?></label>
					<div class="control-group">
						<div class="controls">
						  <input type="text" class="input-xlarge" id="from_email" name="from_email" placeholder="<?php echo _('name@domain.com');?>" value="<?php echo get_app_data('from_email');?>">
						</div>
					</div>
					
					<label class="control-label" for="reply_to"><?php echo _('Reply to email');?></label>
					<div class="control-group">
						<div class="controls">
						  <input type="text" class="input-xlarge" id="reply_to" name="reply_to" placeholder="<?php echo _('name@domain.com');?>" value="<?php echo get_app_data('reply_to');?>">
						</div>
					</div>
			        
			        <label class="control-label" for="plain"><?php echo _('Plain text version');?></label>
		            <div class="control-group">
				    	<div class="controls">
			              <textarea class="input-xlarge" id="plain" name="plain" rows="10" placeholder="<?php echo _('Plain text version of this template');?>"></textarea>
			            </div>
			        </div>
			        
			        <button type="submit" class="btn btn-inverse" id="save-button"><i class="icon-ok icon-white"></i> <?php echo _('Save template');?></button>
			    </div>
		    				    
			    <div class="span9">
			    	<p>
				    	<label class="control-label" for="html"><?php echo _('Email content');?></label>
				    	<div class="btn-group pull-left" data-toggle="buttons-radio">
				    		<button type="button" class="btn editor-mode-toggle<?php if($editor_mode=='dragdrop') echo ' active';?>" data-editor-mode="dragdrop"><i class="icon-move sendy-editor-mode-icon"></i> <?php echo _('Drag &amp; drop');?></button>
				    		<button type="button" class="btn editor-mode-toggle<?php if($editor_mode=='wysiwyg') echo ' active';?>" data-editor-mode="wysiwyg"><i class="icon-font sendy-editor-mode-icon"></i> <?php echo _('WYSIWYG');?></button>
				    		<button type="button" class="btn editor-mode-toggle<?php if($editor_mode=='html') echo ' active';?>" data-editor-mode="html"><i class="icon-file sendy-editor-mode-icon"></i> <?php echo _('HTML');?></button>
				    	</div>
				    	<?php include('includes/helpers/file-manager-button.php');?>
				    	<div style="clear:both;"></div>
				    	<br/>
			            <div class="control-group">
					    	<div class="controls">
				              <div id="gjs" class="sendy-grapesjs-shell"></div>
				              <textarea class="input-xlarge sendy-grapesjs-input" id="html" name="html" rows="10" placeholder="<?php echo _('Email content');?>"></textarea>
				            </div>
				        </div>
				        <p><?php echo _('Use the following tags in your subject, plain text or HTML code and they\'ll automatically be formatted when your campaign is sent. For web version and unsubscribe tags, you can style them with inline CSS.');?></p><br/>
				    	<div class="row-fluid">
					    	<?php include('includes/helpers/personalization.tags.php');?>
				    	</div>
			    	</p>
		    	</div>
		    	<input type="hidden" id="editor_mode" name="editor_mode" value="<?php echo $editor_mode;?>">
		    	<input type="hidden" id="editor_project_data" name="editor_project_data" value="">
		    	
		    </form>
		    
	    </div>
	</div>
</div>
<?php include('includes/footer.php');?>
