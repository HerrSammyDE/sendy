<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//------------------------------------------------------//
	//                      	INIT                       //
	//------------------------------------------------------//
	
	$filename = mysqli_real_escape_string($mysqli, filter_var($_POST['filename'],FILTER_SANITIZE_SPECIAL_CHARS));
	$ares_id = isset($_POST['ares_id']) && is_numeric($_POST['ares_id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['ares_id']) : exit;
	$app_id = isset($_POST['app']) && is_numeric($_POST['app']) ? mysqli_real_escape_string($mysqli, (int)$_POST['app']) : get_app_info('app');
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	//delete file
	$attachment_path = sendy_existing_uploads_path($app_id, 'attachments/a'.$ares_id.'/'.basename($filename), '../../uploads');
	if(unlink($attachment_path))
		echo true;
?>
