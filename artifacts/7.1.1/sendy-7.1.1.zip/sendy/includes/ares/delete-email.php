<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	$id = isset($_POST['id']) && is_numeric($_POST['id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['id']) : exit;
	$app_id = isset($_POST['app']) && is_numeric($_POST['app']) ? mysqli_real_escape_string($mysqli, (int)$_POST['app']) : get_app_info('app');
	
	$q = 'DELETE FROM ares_emails WHERE id = '.$id;
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
		$attachments_path = sendy_existing_uploads_path($app_id, 'attachments/a'.$id, '../../uploads');
		if(file_exists($attachments_path))
		{
			$files = glob($attachments_path.'/*'); // get all file names
			foreach($files as $file){
			    unlink($file); 
			}
			rmdir($attachments_path);
		}
		
		//Delete links
		$q2 = 'DELETE FROM links WHERE ares_emails_id = '.$id;
		mysqli_query($mysqli, $q2);
		
		echo true;
	}
	
?>
