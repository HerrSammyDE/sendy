<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php
	$campaign_id = isset($_POST['campaign_id']) && is_numeric($_POST['campaign_id']) ? (int)$_POST['campaign_id'] : 0;
	$app = isset($_POST['app']) && is_numeric($_POST['app']) ? (int)$_POST['app'] : 0;
	$token = isset($_POST['token']) ? (string)$_POST['token'] : '';
	$expected_token = hash_hmac('sha256', 'cancel-schedule|'.session_id(), get_app_info('auth_salt'));

	if($campaign_id <= 0 || $app <= 0 || !hash_equals($expected_token, $token))
	{
		http_response_code(403);
		exit;
	}

	// A sub-user must not be able to cancel a campaign outside their assigned brand.
	if(get_app_info('is_sub_user') && $app != get_app_info('restricted_to_app'))
	{
		http_response_code(403);
		exit;
	}

	// Use the same advisory lock as scheduled.php so cancellation cannot race
	// with the worker that changes a scheduled campaign to sending.
	$lock_name = mysqli_real_escape_string($mysqli, 'sendy_campaign_send_'.$campaign_id);
	$lock_result = mysqli_query($mysqli, 'SELECT GET_LOCK("'.$lock_name.'", 0) AS lock_status');
	$lock_row = $lock_result ? mysqli_fetch_array($lock_result) : false;
	if(!$lock_row || (int)$lock_row['lock_status'] !== 1)
	{
		http_response_code(409);
		exit;
	}

	mysqli_begin_transaction($mysqli);

	$q = 'SELECT c.quota_deducted, a.allocated_quota
		FROM campaigns c
		INNER JOIN apps a ON a.id = c.app
		WHERE c.id = '.$campaign_id.'
		AND c.app = '.$app.'
		AND c.userID = '.get_app_info('main_userID').'
		AND (c.sent IS NULL OR c.sent = "")
		AND c.send_date IS NOT NULL
		AND c.send_date != ""
		FOR UPDATE';
	$r = mysqli_query($mysqli, $q);

	if(!$r || mysqli_num_rows($r) !== 1)
	{
		mysqli_rollback($mysqli);
		mysqli_query($mysqli, 'DO RELEASE_LOCK("'.$lock_name.'")');
		http_response_code(409);
		exit;
	}

	$row = mysqli_fetch_array($r);
	$quota_deducted = empty($row['quota_deducted']) ? 0 : (int)$row['quota_deducted'];
	$allocated_quota = (int)$row['allocated_quota'];

	$q = 'UPDATE campaigns SET
		send_date = NULL,
		lists = NULL,
		lists_excl = NULL,
		segs = NULL,
		segs_excl = NULL,
		timezone = NULL,
		quota_deducted = 0
		WHERE id = '.$campaign_id.'
		AND app = '.$app.'
		AND userID = '.get_app_info('main_userID').'
		AND (sent IS NULL OR sent = "")
		AND send_date IS NOT NULL
		AND send_date != ""';
	$cancelled = mysqli_query($mysqli, $q);

	if(!$cancelled || mysqli_affected_rows($mysqli) !== 1)
	{
		mysqli_rollback($mysqli);
		mysqli_query($mysqli, 'DO RELEASE_LOCK("'.$lock_name.'")');
		http_response_code(409);
		exit;
	}

	if($allocated_quota != -1 && $quota_deducted > 0)
	{
		$q = 'UPDATE apps SET current_quota = GREATEST(0, current_quota - '.$quota_deducted.') WHERE id = '.$app;
		if(!mysqli_query($mysqli, $q))
		{
			mysqli_rollback($mysqli);
			mysqli_query($mysqli, 'DO RELEASE_LOCK("'.$lock_name.'")');
			http_response_code(500);
			exit;
		}
	}

	if(!mysqli_commit($mysqli))
	{
		mysqli_rollback($mysqli);
		mysqli_query($mysqli, 'DO RELEASE_LOCK("'.$lock_name.'")');
		http_response_code(500);
		exit;
	}

	mysqli_query($mysqli, 'DO RELEASE_LOCK("'.$lock_name.'")');
	echo true;
?>
