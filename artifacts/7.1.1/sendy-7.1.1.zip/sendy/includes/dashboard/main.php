<?php 
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	//------------------------------------------------------//
	function get_app_data($val)
	//------------------------------------------------------//
	{
		global $mysqli;
		$q = 'SELECT '.$val.' FROM apps WHERE id = "'.get_app_info('app').'" AND userID = '.get_app_info('main_userID');
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
		    while($row = mysqli_fetch_array($r))
		    {
				return $row[$val];
		    }  
		}
	}
	
	//------------------------------------------------------//
	function get_click_percentage($cid)
	//------------------------------------------------------//
	{
		global $mysqli;
		$clicks_join = '';
		$clicks_array = array();
		$clicks_unique = 0;
		
		$q = 'SELECT * FROM links WHERE campaign_id = '.$cid;
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
		    while($row = mysqli_fetch_array($r))
		    {
		    	$id = $row['id']=='' ? '' : stripslashes($row['id']);
				$link = $row['link']=='' ? '' : stripslashes($row['link']);
				$clicks = $row['clicks']=='' ? '' : stripslashes($row['clicks']);
				if($clicks!='')
					$clicks_join .= $clicks.',';				
		    }  
		}
		
		$clicks_array = explode(',', $clicks_join);
		$clicks_unique = count(array_unique($clicks_array));
		
		return $clicks_unique-1;
	}
	
	//------------------------------------------------------//
	function totals($app, $type='app')
	//------------------------------------------------------//
	{
		global $mysqli;
			
		if($type=='app')
			$q = 'SELECT id FROM campaigns WHERE app = '.$app.' AND userID = '.get_app_info('main_userID');
		else if($type=='reports')
			$q = 'SELECT id FROM campaigns WHERE app = '.$app.' AND sent!="" AND userID = '.get_app_info('main_userID');
		$r = mysqli_query($mysqli, $q);
		if ($r) return mysqli_num_rows($r);
	}
	
	//------------------------------------------------------//
	function pagination($limit, $type='app')
	//------------------------------------------------------//
	{		
		global $p;
		
		$total_campaigns = $type=='reports' ? totals(get_app_info('app'), 'reports') : totals(get_app_info('app'));
		$base_url = get_app_info('path').'/'.$type.'?i='.get_app_info('app');
		
		sendy_render_pagination($total_campaigns, $limit, $base_url, $p);
	}
	
	//------------------------------------------------------//
	function get_bounced($c)
	//------------------------------------------------------//
	{
		global $mysqli;
		$q = 'SELECT last_campaign FROM subscribers WHERE last_campaign = '.mysqli_real_escape_string($mysqli, $c).' AND bounced = 1';
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
		    return mysqli_num_rows($r); 
		}
		else
		{
			return 0;
		}
	}
	
	//------------------------------------------------------//
	function have_templates()
	//------------------------------------------------------//
	{
		global $mysqli;
		$q = 'SELECT COUNT(*) FROM template WHERE app = '.get_app_info('app').' AND userID = '.get_app_info('main_userID');
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
		    while($row = mysqli_fetch_array($r))
		    {
				$rows = $row['COUNT(*)'];
		    }  
		    return $rows == 0 ? false : true;
		}
	}
?>
