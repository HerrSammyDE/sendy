<?php

if(!function_exists('sendy_get_ai_email_prompt_task'))
{
	function sendy_get_ai_email_prompt_task()
	{
		$reference_url = function_exists('get_app_info') ? get_app_info('path').'/sample-template.html' : 'sample-template.html';
		return 'Create a full responsive HTML email newsletter template inspired by this email: 

- '.$reference_url;
	}
}

if(!function_exists('sendy_get_ai_email_prompt_look_feel'))
{
	function sendy_get_ai_email_prompt_look_feel()
	{
		return '- Match typography, layout and color scheme
- Match number of rows and columns';
	}
}

if(!function_exists('sendy_get_ai_email_prompt_requirements'))
{
	function sendy_get_ai_email_prompt_requirements()
	{
		return '- Use placeholder text, images, and links that I can easily replace.
- Output complete HTML only, ready to paste into an email platform.
- Use table-based email layout with inline CSS.
- Mobile responsive.
- Make it compatible with Gmail, Apple Mail, Outlook, and mobile email clients.
- Avoid JavaScript, external CSS, forms, or unsupported email features.
- Include comments in the HTML showing where to edit logo, hero image, copy, links, CTA, and footer.
- Include a preheader text in the HTML and include comments on where I can edit it.
- Use href="[webversion]" for the web version link and href="[unsubscribe]" for the unsubscribe link.';
	}
}

if(!function_exists('sendy_get_ai_email_prompt'))
{
	function sendy_get_ai_email_prompt()
	{
		return "Task:\n".sendy_get_ai_email_prompt_task()."\n\nLook and feel:\n".sendy_get_ai_email_prompt_look_feel()."\n\nRequirements:\n".sendy_get_ai_email_prompt_requirements();
	}
}

?>
