<?php
	include_once(dirname(__FILE__).'/openai.php');

	if(!isset($ai_subject_target_selector) || $ai_subject_target_selector=='')
		$ai_subject_target_selector = '#subject';

	if(!isset($ai_subject_plain_selector) || $ai_subject_plain_selector=='')
		$ai_subject_plain_selector = '#plain';

	if(!isset($ai_subject_html_selector) || $ai_subject_html_selector=='')
		$ai_subject_html_selector = '#html';

	if(!isset($ai_subject_button_label) || $ai_subject_button_label=='')
		$ai_subject_button_label = _('Generate subject with AI');

	$ai_subject_modal_id = 'sendy-ai-subject-custom-'.substr(md5($ai_subject_target_selector.$ai_subject_plain_selector.$ai_subject_html_selector), 0, 8);
	$ai_subject_client = new SendyOpenAiClient('');
	$ai_subject_compelling_prompt = $ai_subject_client->get_subject_prompt_template('compelling');
	$ai_subject_compelling_prompt = trim(str_replace($ai_subject_client->get_subject_context_template(), '', $ai_subject_compelling_prompt));
	$ai_addon_enabled = sendy_ai_addon_enabled();
	$ai_disabled = sendy_brand_ai_disabled();
?>
<?php if(!$ai_disabled):?>
	<style type="text/css">
		@keyframes sendyAiRainbowPulse {
			0% { background-position: 0% 50%; }
			100% { background-position: 200% 50%; }
		}
		.btn-group > .sendy-ai-subject-btn,
		.btn-group > .sendy-ai-subject-btn:first-child,
		.btn-group > .sendy-ai-subject-btn:last-child,
		.btn-group > .sendy-ai-subject-btn.dropdown-toggle {
			-webkit-border-radius: 20px !important;
			-moz-border-radius: 20px !important;
			border-radius: 20px !important;
		}
		.sendy-ai-subject-btn .sendy-ai-rainbow-text {
			animation: sendyAiRainbowPulse 2s linear infinite;
			background-image: linear-gradient(90deg, #993FED 0%, #007bff 18%, #16a34a 36%, #f59e0b 54%, #ef4444 72%, #993FED 90%, #007bff 100%) !important;
		background-size: 200% 100% !important;
		background-position: 0% 50%;
		-webkit-background-clip: text !important;
		background-clip: text !important;
		color: #993FED !important;
		-webkit-text-fill-color: transparent !important;
			display: inline-block;
			font-weight: bold;
		}
	</style>
	<div class="control-group sendy-ai-subject-shell" style="margin-top: -10px; margin-bottom: 20px;">
		<div class="controls">
			<?php if($ai_addon_enabled):?>
				<div class="btn-group">
					<button
						type="button"
						class="btn dropdown-toggle sendy-ai-subject-btn"
						data-toggle="dropdown"
						data-endpoint="<?php echo get_app_info('path');?>/includes/ai/generate-subject.php"
						data-app-id="<?php echo get_app_info('app');?>"
						data-subject-selector="<?php echo htmlspecialchars($ai_subject_target_selector, ENT_QUOTES, 'UTF-8');?>"
						data-plain-selector="<?php echo htmlspecialchars($ai_subject_plain_selector, ENT_QUOTES, 'UTF-8');?>"
						data-html-selector="<?php echo htmlspecialchars($ai_subject_html_selector, ENT_QUOTES, 'UTF-8');?>"
						data-custom-modal="#<?php echo $ai_subject_modal_id;?>"
						data-generating-label="<?php echo htmlspecialchars(_('Generating...'), ENT_QUOTES, 'UTF-8');?>"
						data-generating-text="<?php echo htmlspecialchars(_('Generating subject line...'), ENT_QUOTES, 'UTF-8');?>"
						data-empty-text="<?php echo htmlspecialchars(_('Add some email content before generating a subject line.'), ENT_QUOTES, 'UTF-8');?>"
						data-success-text="<?php echo htmlspecialchars(_('Subject line generated.'), ENT_QUOTES, 'UTF-8');?>"
						data-generic-error-text="<?php echo htmlspecialchars(_('Unable to generate a subject line right now.'), ENT_QUOTES, 'UTF-8');?>"
					>
						<i class="icon icon-magic"></i> <span class="sendy-ai-rainbow-text"><?php echo $ai_subject_button_label;?></span> <span class="caret"></span>
					</button>
					<ul class="dropdown-menu">
						<li><a href="javascript:void(0);" class="sendy-ai-subject-option" data-prompt-mode="compelling"><?php echo _('Compelling');?></a></li>
						<li><a href="javascript:void(0);" class="sendy-ai-subject-option" data-prompt-mode="curiosity"><?php echo _('Curiosity based');?></a></li>
						<li><a href="javascript:void(0);" class="sendy-ai-subject-option" data-prompt-mode="value"><?php echo _('Value based');?></a></li>
						<li><a href="javascript:void(0);" class="sendy-ai-subject-option" data-prompt-mode="personal"><?php echo _('Personal tone');?></a></li>
						<li><a href="javascript:void(0);" class="sendy-ai-subject-custom-option"><?php echo _('Custom');?></a></li>
					</ul>
				</div>
				<div class="alert sendy-ai-subject-message" style="display:none; margin-top:10px;"></div>
				<?php else:?>
					<div class="btn-group">
						<a href="#sendy-ai-paywall-modal" data-toggle="modal" data-sendy-ai-demo="generate-subject-with-ai" class="btn dropdown-toggle sendy-ai-subject-btn"><i class="icon icon-magic"></i> <span class="sendy-ai-rainbow-text"><?php echo $ai_subject_button_label;?></span> <span class="caret"></span></a>
					</div>
					<?php echo sendy_ai_paywall_modal_html();?>
				<?php endif;?>
		</div>

		<?php if($ai_addon_enabled):?>
			<div id="<?php echo $ai_subject_modal_id;?>" class="modal hide fade sendy-ai-subject-custom-modal" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h3><?php echo _('Custom AI subject prompt');?></h3>
				</div>
				<div class="modal-body">
					<textarea class="input-xlarge sendy-ai-subject-custom-prompt" rows="14" style="width: 96%;"><?php echo htmlspecialchars($ai_subject_compelling_prompt, ENT_QUOTES, 'UTF-8');?></textarea>
				</div>
				<div class="modal-footer">
					<a href="javascript:void(0);" class="btn btn-primary sendy-ai-subject-custom-generate"><?php echo _('Generate');?></a>
				</div>
			</div>
		<?php endif;?>
</div>
<?php endif;?>
