<?php
	include_once('includes/helpers/content-improvements-analysis.php');
	include_once('includes/helpers/report-analysis.php');

	$sendy_content_type = isset($sendy_content_type) ? $sendy_content_type : 'campaign';
	$sendy_content_id = isset($sendy_content_id) ? (int)$sendy_content_id : 0;
	$sendy_content_parent_id = isset($sendy_content_parent_id) ? (int)$sendy_content_parent_id : 0;
	$sendy_content_analysis = sendy_content_improvements_get($sendy_content_type, $sendy_content_id, $sendy_content_parent_id, get_app_info('app'), get_app_info('main_userID'));
	$sendy_content_analysis_is_open = $sendy_content_analysis && (int)$sendy_content_analysis['is_open'] == 1;
	$sendy_content_analysis_content = $sendy_content_analysis && isset($sendy_content_analysis['analysis']) ? $sendy_content_analysis['analysis'] : '';
	$ai_addon_enabled = sendy_ai_addon_enabled();
	$ai_disabled = sendy_brand_ai_disabled();
	if($ai_disabled)
	{
		$sendy_content_analysis_is_open = false;
		$sendy_content_analysis_content = '';
	}
?>
<style type="text/css">
	@keyframes sendyAiRainbowPulse {
		0% { background-position: 0% 50%; }
		100% { background-position: 200% 50%; }
	}
	.sendy-content-improvements-btn .sendy-ai-rainbow-text,
	.sendy-content-improvements-paywall-btn .sendy-ai-rainbow-text {
		animation: sendyAiRainbowPulse 2s linear infinite;
		background-image: linear-gradient(90deg, #993FED 0%, #007bff 18%, #16a34a 36%, #f59e0b 54%, #ef4444 72%, #993FED 90%, #007bff 100%) !important;
		background-size: 200% 100% !important;
		background-position: 0% 50%;
		-webkit-background-clip: text !important;
		background-clip: text !important;
		color: #993FED !important;
		-webkit-text-fill-color: transparent !important;
		display: inline-block;
		font-weight: bold;
	}
</style>
<div class="sendy-content-improvements-shell pull-right" data-endpoint="<?php echo get_app_info('path');?>/includes/ai/suggest-improvements.php" data-state-endpoint="<?php echo get_app_info('path');?>/includes/ai/content-improvements-state.php" data-app-id="<?php echo get_app_info('app');?>" data-content-type="<?php echo htmlspecialchars($sendy_content_type, ENT_QUOTES, 'UTF-8');?>" data-content-id="<?php echo $sendy_content_id;?>" data-parent-id="<?php echo $sendy_content_parent_id;?>">
		<?php if(!$ai_disabled):?>
		<a href="javascript:void(0);" class="btn sendy-content-improvements-reopen-btn" data-open-label="<?php echo htmlspecialchars(_('Open last analysis'), ENT_QUOTES, 'UTF-8');?>" data-close-label="<?php echo htmlspecialchars(_('Close analysis'), ENT_QUOTES, 'UTF-8');?>" style="<?php echo $sendy_content_analysis_content=='' ? 'display:none;' : '';?>"><i class="icon icon-folder-open"></i> <?php echo $sendy_content_analysis_is_open ? _('Close analysis') : _('Open last analysis');?></a>
		<?php endif;?>
		<?php if(!$ai_disabled && $ai_addon_enabled):?>
			<a href="javascript:void(0);" class="btn sendy-content-improvements-btn" data-label-suggest="<?php echo htmlspecialchars(_('Suggest improvements'), ENT_QUOTES, 'UTF-8');?>" data-label-resuggest="<?php echo htmlspecialchars(_('Resuggest improvements'), ENT_QUOTES, 'UTF-8');?>" data-loading-text="<?php echo htmlspecialchars(_('Analyzing...'), ENT_QUOTES, 'UTF-8');?>" data-error-text="<?php echo htmlspecialchars(_('Unable to suggest improvements right now.'), ENT_QUOTES, 'UTF-8');?>"><i class="icon icon-magic"></i> <span class="sendy-ai-rainbow-text"><?php echo $sendy_content_analysis_content=='' ? _('Suggest improvements') : _('Resuggest improvements');?></span></a>
		<?php elseif(!$ai_disabled):?>
			<a href="#sendy-ai-paywall-modal" data-toggle="modal" data-sendy-ai-demo="suggest-improvements" class="btn sendy-content-improvements-paywall-btn"><i class="icon icon-magic"></i> <span class="sendy-ai-rainbow-text"><?php echo $sendy_content_analysis_content=='' ? _('Suggest improvements') : _('Resuggest improvements');?></span></a>
		<?php endif;?>
</div>
<?php if(!$ai_disabled && !$ai_addon_enabled) echo sendy_ai_paywall_modal_html();?>
<div class="sendy-content-improvements-panel" style="<?php echo $sendy_content_analysis_is_open ? '' : 'display:none;';?>">
	<a href="javascript:void(0);" class="close sendy-content-improvements-close">&times;</a>
	<h2 style="margin-top:0;"><i class="icon icon-magic"></i> <?php echo _('Suggested Improvements');?></h2>
	<div class="sendy-content-improvements-content" style="line-height: 1.5;"><?php echo sendy_report_analysis_html($sendy_content_analysis_content);?></div>
</div>
