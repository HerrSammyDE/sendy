<?php
	require_once('includes/helpers/ses-sidebar-data.php');
	$ses_sidebar_data = sendy_get_ses_sidebar_data();
	$has_ses_setup = $ses_sidebar_data['has_ses_setup'];
	$testAWSCreds = $ses_sidebar_data['testAWSCreds'];
	$daily_quota = $ses_sidebar_data['daily_quota'];
	$sends_left = $ses_sidebar_data['sends_left'];
	$sent_today = $ses_sidebar_data['sent_today'];
	$send_rate = $ses_sidebar_data['send_rate'];
	$quota_color = $ses_sidebar_data['quota_color'];
	$ses_reputation = $ses_sidebar_data['ses_reputation'];

	if(!$has_ses_setup):
?>
<h3><span class="icon icon-envelope-alt"></span> <?php echo _('Ways to send emails');?></h3><br/>
<p><strong>1️⃣ Send emails via Amazon SES</strong></p>
<p><?php echo _('Follow Step 5 of the <a href="https://sendy.co/get-started#step5" target="_blank" style="text-decoration: underline">Get Started Guide</a> to hook up your Amazon SES account with your Sendy installation.');?></p>
<p><strong>2️⃣ Send emails via other SMTP services</strong></p>
<p><?php echo _('Save the SMTP credentials generated from the email sending service of your choice under \'SMTP settings\' when creating or editing a brand. Or choose from a list of supported SMTP providers like Elastic Email, Sendgrid or MailJet.');?></p>

<?php else:?>
<?php if(is_array($testAWSCreds) && $ses_reputation !== null):?>
<h3><?php echo _('Amazon SES Status');?></h3><br/>
<p><strong><?php echo _('Status');?>:</strong> <span class="label <?php echo $ses_reputation['status_class'];?>"><?php echo $ses_reputation['status'];?></span></p>
<p><strong><?php echo _('Sending');?>:</strong> <span class="label <?php echo $ses_reputation['account_status_class'];?>"><?php echo $ses_reputation['account_status'];?></span></p>
<br/>
<?php endif;?>
<h3><?php echo _('Amazon SES Quota');?></h3><br/>
<p><strong><?php echo _('SES region');?>:</strong> <span class="label <?php echo $quota_color;?>"><?php echo get_app_info('ses_region');?></span></p>
<?php if(is_array($testAWSCreds)):?>
<p><strong><?php echo _('Daily quota');?>:</strong> <span class="label <?php echo $quota_color;?>"><?php echo number_format($daily_quota);?></span></p>
<p><strong><?php echo _('Sends left');?>:</strong> <span class="label <?php echo $quota_color;?>"><?php echo number_format($sends_left);?></span></p>
<p><strong><?php echo _('Sent today');?>:</strong> <span class="label <?php echo $quota_color;?>"><?php echo number_format($sent_today);?></span></p>
<p><strong><?php echo _('Send rate');?>:</strong> <span class="label <?php echo $quota_color;?>"><?php echo number_format($send_rate);?> <?php echo _('per sec');?></span></p>
<?php endif;?>

<?php if($testAWSCreds=='AccessDenied'):?>
<br/>
<span style="color:#BB4D47;"><p><strong><?php echo _('Error');?>: AccessDenied</strong></p><p><?php echo _('Your Sendy installation is unable to get your SES quota from Amazon because you did not attach "AmazonSESFullAccess" user policy to your IAM credentials. Please re-do Step 5.2 and 5.3 of the <a href="https://sendy.co/get-started#step5" target="_blank">Get Started Guide</a> carefully to resolve this error.');?></p></span>

<?php elseif($testAWSCreds=='RequestExpired'):?>
<br/>
<span style="color:#BB4D47;"><p><strong><?php echo _('Error');?>: RequestExpired</strong></p><p><?php echo _('Your Sendy installation is unable to get your SES quota from Amazon because your server clock is out of sync with NTP. To fix this, Amazon requires you to <strong>sync your server clock with NTP</strong>. Request your host to sync your server clock with NTP with the following command via SSH:');?></p><p><code>sudo /usr/sbin/ntpdate 0.north-america.pool.ntp.org 1.north-america.pool.ntp.org 2.north-america.pool.ntp.org 3.north-america.pool.ntp.org</code></p></span>

<?php elseif($testAWSCreds=='InvalidClientTokenId' || $testAWSCreds=='SignatureDoesNotMatch'):?>
<br/>
<span style="color:#BB4D47;"><p><strong><?php echo _('Error');?>: <?php echo $testAWSCreds;?></strong></p><p><?php echo _('Your Sendy installation is unable to get your SES quota from Amazon because the \'Amazon Web Services Credentials\' set in Sendy\'s main Settings are incorrect. You probably did not copy and pasted your IAM credentials fully or properly into the settings. Please re-do Step 5.2 and 5.3 of the <a href="https://sendy.co/get-started#step5" target="_blank">Get Started Guide</a> carefully to resolve this error.');?></p></span>

<?php elseif($testAWSCreds=='OptInRequired'):?>
<br/>
<span style="color:#BB4D47;"><p><strong><?php echo _('Error');?>: OptInRequired</strong></p><p><?php echo _('Your Sendy installation is unable to get your SES quota from Amazon because you have not completed your sign up of Amazon SES. Here\'s what you should do:');?></p><ol><li><?php echo _('Visit');?> <a href="https://console.aws.amazon.com/ses/signup" target="_blank"><?php echo _('your Amazon SES console');?></a></li><li><?php echo _('Click the \'Sign Up For Amazon SES\' button to finish your signup');?></li></ol><p><?php echo _('Once you\'ve completed your signup, this error will disappear.');?></p></span>

<?php elseif($daily_quota=='200'):?>
<br/>
<span style="color:#BB4D47;"><p><?php echo _('You\'re currently in Amazon SES\'s "Sandbox mode".');?></p><p><?php echo _('Please request Amazon to "<a href="https://console.aws.amazon.com/ses/home#/account/request-production-access" target="_blank" class="ses-quota-production-link">raise your SES Sending Limits</a>" to be able to send to and from any email address as well as raise your daily sending quota from 200 to any number you need.');?></p><p><?php echo _('Please also make sure to select the same \'Region\' as what is set in your Sendy Settings (under \'Amazon SES region\') when requesting for \'SES Sending Limits\' increase.');?></p></span>

<?php elseif(!is_array($testAWSCreds) && $testAWSCreds!=''):?>
<br/>
<span style="color:#BB4D47;"><p><strong><?php echo _('Error');?>: <?php echo htmlspecialchars($testAWSCreds, ENT_QUOTES, 'UTF-8');?></strong></p></span>

<?php endif;
	endif;
?>
