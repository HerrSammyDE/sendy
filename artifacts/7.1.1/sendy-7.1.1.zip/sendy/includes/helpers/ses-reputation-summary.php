<?php
	require_once('includes/helpers/ses-sidebar-data.php');
	$ses_sidebar_data = sendy_get_ses_sidebar_data();
	$ses_reputation = $ses_sidebar_data['ses_reputation'];
	$testAWSCreds = $ses_sidebar_data['testAWSCreds'];
	$ses_reputation_layout = isset($ses_reputation_layout) ? $ses_reputation_layout : 'vertical';

	if(is_array($testAWSCreds) && $ses_reputation !== null):
?>
<?php if($ses_reputation_layout == 'horizontal'):?>
<div class="sidebar-nav sidebar-box" style="padding: 12px 19px 20px; margin-bottom: 20px;">
	<div class="row-fluid">
		<div class="span2" style="text-align: center;">
			<p style="margin: 0 0 8px;"><strong><?php echo _('Account status');?></strong></p>
			<span class="label <?php echo $ses_reputation['status_class'];?>"><?php echo $ses_reputation['status'];?></span>
		</div>
		<div class="span2" style="text-align: center;">
			<p style="margin: 0 0 8px;"><strong><?php echo _('Account sending');?></strong></p>
			<span class="label <?php echo $ses_reputation['account_status_class'];?>"><?php echo $ses_reputation['account_status'];?></span>
		</div>
		<div class="span2" style="text-align: center;">
			<p style="margin: 0 0 8px;"><strong><?php echo _('Delivery attempts');?></strong></p>
			<span class="label label-success"><?php echo number_format($ses_reputation['delivery_attempts']);?></span>
		</div>
		<div class="span2" style="text-align: center;">
			<p style="margin: 0 0 8px;"><strong><?php echo _('Bounce rate');?></strong></p>
			<span class="label label-success"><?php echo number_format($ses_reputation['bounce_rate'], 2);?>% (<?php echo number_format($ses_reputation['bounces']);?>)</span>
		</div>
		<div class="span2" style="text-align: center;">
			<p style="margin: 0 0 8px;"><strong><?php echo _('Complaint rate');?></strong></p>
			<span class="label label-success"><?php echo number_format($ses_reputation['complaint_rate'], 2);?>% (<?php echo number_format($ses_reputation['complaints']);?>)</span>
		</div>
		<div class="span2" style="text-align: center;">
			<p style="margin: 0 0 8px;"><strong><?php echo _('Rejects');?></strong></p>
			<span class="label label-success"><?php echo number_format($ses_reputation['rejects']);?></span>
		</div>
	</div>
</div>
<?php else:?>
<div class="sidebar-nav sidebar-box" style="padding: 19px; margin-top: 20px;">
	<p><strong><?php echo _('Account status');?>:</strong> <span class="label <?php echo $ses_reputation['status_class'];?>"><?php echo $ses_reputation['status'];?></span></p>
	<p><strong><?php echo _('Account sending');?>:</strong> <span class="label <?php echo $ses_reputation['account_status_class'];?>"><?php echo $ses_reputation['account_status'];?></span></p>
	<p><strong><?php echo _('Delivery attempts');?>:</strong> <span class="label label-success"><?php echo number_format($ses_reputation['delivery_attempts']);?></span></p>
	<p><strong><?php echo _('Bounce rate');?>:</strong> <span class="label label-success"><?php echo number_format($ses_reputation['bounce_rate'], 2);?>% (<?php echo number_format($ses_reputation['bounces']);?>)</span></p>
	<p><strong><?php echo _('Complaint rate');?>:</strong> <span class="label label-success"><?php echo number_format($ses_reputation['complaint_rate'], 2);?>% (<?php echo number_format($ses_reputation['complaints']);?>)</span></p>
	<p><strong><?php echo _('Rejects');?>:</strong> <span class="label label-success"><?php echo number_format($ses_reputation['rejects']);?></span></p>
</div>
<?php endif;?>
<?php endif;?>
