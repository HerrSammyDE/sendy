<?php
	if(!function_exists('sendy_apply_ses_enforcement_status'))
	{
		function sendy_apply_ses_enforcement_status(&$snapshot, $account)
		{
			if(!is_array($account) || !isset($account['EnforcementStatus']) || $account['EnforcementStatus'] == '')
				return false;

			$snapshot['enforcement_status'] = strtoupper($account['EnforcementStatus']);
			if($snapshot['enforcement_status'] === 'HEALTHY')
			{
				$snapshot['status'] = _('Healthy');
				$snapshot['status_class'] = 'label-success';
			}
			else if($snapshot['enforcement_status'] === 'PROBATION')
			{
				$snapshot['status'] = _('Probation');
				$snapshot['status_class'] = 'label-warning';
			}
			else if($snapshot['enforcement_status'] === 'SHUTDOWN')
			{
				$snapshot['status'] = _('Shutdown');
				$snapshot['status_class'] = 'label-important';
			}
			else
			{
				$snapshot['status'] = ucwords(strtolower(str_replace('_', ' ', $snapshot['enforcement_status'])));
				$snapshot['status_class'] = 'label';
			}

			return true;
		}
	}

	if(!function_exists('sendy_get_ses_reputation_snapshot'))
	{
		function sendy_get_ses_reputation_snapshot($statistics, $sending_enabled, $account = null)
		{
			$snapshot = array(
				'has_activity' => false,
				'status' => _('No recent activity'),
				'status_class' => 'label-info',
				'enforcement_status' => '',
				'account_status' => $sending_enabled === 'Disabled' ? _('Paused') : _('Enabled'),
				'account_status_class' => $sending_enabled === 'Disabled' ? 'label-important' : 'label-success',
				'delivery_attempts' => 0,
				'bounces' => 0,
				'complaints' => 0,
				'rejects' => 0,
				'bounce_rate' => 0,
				'complaint_rate' => 0,
			);

			if(is_array($account) && isset($account['SendingEnabled']))
			{
				$sending_enabled = $account['SendingEnabled'] ? 'Enabled' : 'Disabled';
				$snapshot['account_status'] = $account['SendingEnabled'] ? _('Enabled') : _('Paused');
				$snapshot['account_status_class'] = $account['SendingEnabled'] ? 'label-success' : 'label-important';
			}

			if($sending_enabled !== 'Enabled' && $sending_enabled !== 'Disabled')
			{
				$snapshot['account_status'] = _('Unavailable');
				$snapshot['account_status_class'] = 'label';
			}

			if(is_array($statistics) && isset($statistics['SendDataPoints']) && is_array($statistics['SendDataPoints']))
			{
				foreach($statistics['SendDataPoints'] as $datapoint)
				{
					$snapshot['delivery_attempts'] += isset($datapoint['DeliveryAttempts']) ? (int)$datapoint['DeliveryAttempts'] : 0;
					$snapshot['bounces'] += isset($datapoint['Bounces']) ? (int)$datapoint['Bounces'] : 0;
					$snapshot['complaints'] += isset($datapoint['Complaints']) ? (int)$datapoint['Complaints'] : 0;
					$snapshot['rejects'] += isset($datapoint['Rejects']) ? (int)$datapoint['Rejects'] : 0;
				}

				$snapshot['has_activity'] = $snapshot['delivery_attempts'] > 0;
				if($snapshot['has_activity'])
				{
					$snapshot['bounce_rate'] = round(($snapshot['bounces'] / $snapshot['delivery_attempts']) * 100, 2);
					$snapshot['complaint_rate'] = round(($snapshot['complaints'] / $snapshot['delivery_attempts']) * 100, 2);
				}
			}

			if(sendy_apply_ses_enforcement_status($snapshot, $account))
				return $snapshot;

			if($sending_enabled === 'Disabled')
			{
				$snapshot['status'] = _('Sending paused');
				$snapshot['status_class'] = 'label-important';
			}
			else if(!$snapshot['has_activity'])
			{
				$snapshot['status'] = _('No recent activity');
				$snapshot['status_class'] = 'label-info';
			}
			else if($snapshot['bounce_rate'] >= 5 || $snapshot['complaint_rate'] >= 0.1)
			{
				$snapshot['status'] = _('At risk');
				$snapshot['status_class'] = 'label-important';
			}
			else if($snapshot['bounce_rate'] >= 2 || $snapshot['complaint_rate'] >= 0.05)
			{
				$snapshot['status'] = _('Needs attention');
				$snapshot['status_class'] = 'label-warning';
			}
			else
			{
				$snapshot['status'] = _('Healthy');
				$snapshot['status_class'] = 'label-success';
			}

			return $snapshot;
		}
	}

	if(!function_exists('sendy_get_ses_sidebar_data'))
	{
		function sendy_get_ses_sidebar_data()
		{
			static $ses_sidebar_data = null;

			if($ses_sidebar_data !== null)
				return $ses_sidebar_data;

			$ses_sidebar_data = array(
				'has_ses_setup' => !(get_app_info('s3_key')=='' && get_app_info('s3_secret')==''),
				'testAWSCreds' => '',
				'daily_quota' => 0,
				'sends_left' => 0,
				'sent_today' => 0,
				'send_rate' => 0,
				'quota_color' => '',
				'ses_reputation' => null,
			);

			if(!$ses_sidebar_data['has_ses_setup'])
				return $ses_sidebar_data;

			require_once('includes/helpers/ses.php');
			$ses = new SimpleEmailService(get_app_info('s3_key'), get_app_info('s3_secret'), get_app_info('ses_endpoint'));
			$ses_sidebar_data['testAWSCreds'] = $ses->getSendQuota();

			if(is_array($ses_sidebar_data['testAWSCreds']) && isset($ses_sidebar_data['testAWSCreds']['Max24HourSend']))
			{
				$ses_sidebar_data['daily_quota'] = round($ses_sidebar_data['testAWSCreds']['Max24HourSend']);
				$ses_sidebar_data['sent_today'] = round($ses_sidebar_data['testAWSCreds']['SentLast24Hours']);
				$ses_sidebar_data['sends_left'] = $ses_sidebar_data['daily_quota'] - $ses_sidebar_data['sent_today'];
				$ses_sidebar_data['send_rate'] = round($ses_sidebar_data['testAWSCreds']['MaxSendRate']);

				if($ses_sidebar_data['daily_quota']==0) $ses_sidebar_data['quota_color'] = 'label-important';
				else if($ses_sidebar_data['daily_quota']==200) $ses_sidebar_data['quota_color'] = '';
				else $ses_sidebar_data['quota_color'] = 'label-success';

				$ses_account = $ses->getAccount();
				$ses_statistics = $ses->getSendStatistics();
				$ses_sending_enabled = $ses->getAccountSendingEnabled();
				$ses_sidebar_data['ses_reputation'] = sendy_get_ses_reputation_snapshot($ses_statistics, $ses_sending_enabled, $ses_account);
			}

			return $ses_sidebar_data;
		}
	}
?>
