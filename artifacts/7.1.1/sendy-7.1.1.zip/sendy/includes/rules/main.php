<?php 
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	//------------------------------------------------------//
	function get_app_data($val)
	//------------------------------------------------------//
	{
		global $mysqli;
		$q = 'SELECT '.$val.' FROM apps WHERE id = "'.get_app_info('app').'" AND userID = '.get_app_info('main_userID');
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
		    while($row = mysqli_fetch_array($r))
		    {
				return $row[$val];
		    }  
		}
	}
	
	//------------------------------------------------------//
	function get_data($val, $table, $id)
	//------------------------------------------------------//
	{
		global $mysqli;
		$q = 'SELECT '.$val.' FROM '.$table.' WHERE id = '.$id;
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
		    while($row = mysqli_fetch_array($r))
		    {
				return $row[$val];
		    }  
		}
	}
	
	//------------------------------------------------------//
	function totals($app)
	//------------------------------------------------------//
	{
		global $mysqli;
		global $privileges;
			
		$q = 'SELECT id FROM rules WHERE brand = '.$app.' '.$privileges;
		$r = mysqli_query($mysqli, $q);
		if ($r) return mysqli_num_rows($r);
	}
	
	//------------------------------------------------------//
	function get_lists($app)
	//------------------------------------------------------//
	{
		global $mysqli;
			
		//Get sorting preference
		$q = 'SELECT templates_lists_sorting FROM apps WHERE id = '.$app;
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0) while($row = mysqli_fetch_array($r)) $templates_lists_sorting = $row['templates_lists_sorting'];
		$sortby = $templates_lists_sorting=='date' ? 'id DESC' : 'name ASC';
				
		//Get lists
		$q = 'SELECT id, name FROM lists WHERE app = '.$app.' ORDER BY '.$sortby;
		$r = mysqli_query($mysqli, $q);
		$data = '<li class="dropdown-header">'._('Lists').'</li>
				 <li class="divider"></li>';
		if (mysqli_num_rows($r) > 0) 
		{
			while($row = mysqli_fetch_array($r))
		    {
				$id = $row['id'];
				$name = $row['name'];
				$data .= '<li><a href="javascript:void(0)" class="list" data-list-id="'.$id.'">'.$name.'</a></li>';
		    }
		}
		else
		{
			$data .= '<li><a href="javascript:void(0)" class="list" data-list-id="">'._('No lists found').'</a></li>';
		}
		return $data;
	}
	
	//------------------------------------------------------//
	function pagination($limit, $type='rules')
	//------------------------------------------------------//
	{		
		global $p;
		
		$total_rules = totals(get_app_info('app'));
		$base_url = get_app_info('path').'/'.$type.'?i='.get_app_info('app');
		
		sendy_render_pagination($total_rules, $limit, $base_url, $p);
	}
?>
