<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//------------------------------------------------------//
	//                      VARIABLES                       //
	//------------------------------------------------------//

	if(!function_exists('sendy_settings_post'))
	{
		function sendy_settings_post($key, $default='')
		{
			return isset($_POST[$key]) ? $_POST[$key] : $default;
		}
	}
	
	$userID = isset($_POST['uid']) && is_numeric($_POST['uid']) ? mysqli_real_escape_string($mysqli, (int)$_POST['uid']) : exit;
	$company = mysqli_real_escape_string($mysqli, sendy_settings_post('company'));
	$name = mysqli_real_escape_string($mysqli, sendy_settings_post('personal_name'));
	$email = mysqli_real_escape_string($mysqli, sendy_settings_post('email'));
	$password = mysqli_real_escape_string($mysqli, sendy_settings_post('password'));
	$aws_key = mysqli_real_escape_string($mysqli, trim(sendy_settings_post('aws_key')));
	$aws_secret = mysqli_real_escape_string($mysqli, trim(sendy_settings_post('aws_secret')));
	$paypal = mysqli_real_escape_string($mysqli, sendy_settings_post('paypal'));
	$timezone = mysqli_real_escape_string($mysqli, sendy_settings_post('timezone'));
	$language = mysqli_real_escape_string($mysqli, sendy_settings_post('language'));
	$ses_endpoint = mysqli_real_escape_string($mysqli, sendy_settings_post('ses_endpoint'));
	$send_rate = is_numeric(sendy_settings_post('send_rate')) ? mysqli_real_escape_string($mysqli, (int)sendy_settings_post('send_rate')) : '';
	$ses_send_rate = mysqli_real_escape_string($mysqli, sendy_settings_post('ses_send_rate'));
	$brands_rows = is_numeric(sendy_settings_post('brands_rows')) ? mysqli_real_escape_string($mysqli, (int)sendy_settings_post('brands_rows')) : 10;
	$strict_delete = is_numeric(sendy_settings_post('strict_delete')) ? mysqli_real_escape_string($mysqli, (int)sendy_settings_post('strict_delete')) : 0;
	$dark_mode = is_numeric(sendy_settings_post('dark_mode')) ? mysqli_real_escape_string($mysqli, (int)sendy_settings_post('dark_mode')) : 0;
	$dark_mode_shortcut = preg_match('/^[A-Za-z0-9]$/', sendy_settings_post('dark_mode_shortcut')) ? mysqli_real_escape_string($mysqli, strtoupper(sendy_settings_post('dark_mode_shortcut'))) : 'D';
	
	//Validate send rate settings
	if($send_rate!='' && $ses_send_rate!='')
	{
		if($send_rate==0 || $send_rate=='' || $send_rate==$ses_send_rate) $send_rate = 'NULL';
		else if($send_rate > $ses_send_rate) $send_rate = $ses_send_rate;
	}
	
	//app data
	$from_name = isset($_POST['from_name']) ? mysqli_real_escape_string($mysqli, $_POST['from_name']) : '';
	$from_email = isset($_POST['from_email']) ? mysqli_real_escape_string($mysqli, $_POST['from_email']) : '';
	$reply_to = isset($_POST['reply_to']) ? mysqli_real_escape_string($mysqli, $_POST['reply_to']) : '';
	$smtp_host = isset($_POST['smtp_host']) ? mysqli_real_escape_string($mysqli, $_POST['smtp_host']) : '';
	$smtp_port = isset($_POST['smtp_port']) ? mysqli_real_escape_string($mysqli, $_POST['smtp_port']) : '';
	$smtp_ssl = isset($_POST['smtp_ssl']) ? mysqli_real_escape_string($mysqli, $_POST['smtp_ssl']) : '';
	$smtp_username = isset($_POST['smtp_username']) ? mysqli_real_escape_string($mysqli, $_POST['smtp_username']) : '';
	$smtp_password = isset($_POST['smtp_password']) ? mysqli_real_escape_string($mysqli, $_POST['smtp_password']) : '';
	$smtp_password_line = $smtp_password=='' ? '' : ', smtp_password = "'.$smtp_password.'"';
	$ai_addon_enabled = sendy_ai_addon_enabled();
	$openai_api_key = $ai_addon_enabled && isset($_POST['openai_api_key']) ? mysqli_real_escape_string($mysqli, $_POST['openai_api_key']) : '';
	$clear_openai_api_key = $ai_addon_enabled && isset($_POST['clear_openai_api_key']) && $_POST['clear_openai_api_key']==1 ? 1 : 0;
	$openai_api_key_line = $clear_openai_api_key ? ', openai_api_key = ""' : ($openai_api_key=='' ? '' : ', openai_api_key = "'.$openai_api_key.'"');
	$ai_disabled = isset($_POST['ai_disabled']) && $_POST['ai_disabled']==1 ? 1 : 0;
	$campaign_report_rows = is_numeric(sendy_settings_post('campaign_report_rows')) ? mysqli_real_escape_string($mysqli, (int)sendy_settings_post('campaign_report_rows')) : 10;
	$query_string = mysqli_real_escape_string($mysqli, sendy_settings_post('query_string'));
	$gdpr_only = isset($_POST['gdpr_only']) && $_POST['gdpr_only']==1 ? 1 : 0;
	$gdpr_only_ar = isset($_POST['gdpr_only_ar']) && $_POST['gdpr_only_ar']==1 ? 1 : 0;
	$gdpr_options = isset($_POST['gdpr_options']) && $_POST['gdpr_options']==1 ? 1 : 0;
	$recaptcha_sitekey = mysqli_real_escape_string($mysqli, sendy_settings_post('recaptcha_sitekey'));
	$recaptcha_secretkey = mysqli_real_escape_string($mysqli, sendy_settings_post('recaptcha_secretkey'));
	$test_email_prefix = mysqli_real_escape_string($mysqli, sendy_settings_post('test_email_prefix'));
	$templates_lists_sorting = mysqli_real_escape_string($mysqli, sendy_settings_post('templates_lists_sorting', 'date'));
	$opens_tracking = isset($_POST['opens']) && is_numeric($_POST['opens']) ? mysqli_real_escape_string($mysqli, (int)$_POST['opens']) : 1;
	$links_tracking = isset($_POST['clicks']) && is_numeric($_POST['clicks']) ? mysqli_real_escape_string($mysqli, (int)$_POST['clicks']) : 1;
	
	if($password=='')
		$change_pass = false;
	else
	{
		$change_pass = true;
		$pass_encrypted = hash('sha512', $password.'PectGtma');		
	}
	
	$aws_secret_query = '';
	if($aws_key=='')
		$aws_secret_query = ', s3_secret=""';
	else if($aws_secret!='')
		$aws_secret_query = ', s3_secret="'.$aws_secret.'"';
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	//Check if email exists in login table
	$q = 'SELECT username FROM login WHERE username = "'.$email.'" AND id != '.get_app_info('userID');
	$r = mysqli_query($mysqli, $q);
	if (mysqli_num_rows($r) > 0)
	{
		echo "email exists";
		exit;
	}
		
	if(!get_app_info('is_sub_user'))
	{
		if($change_pass)
			$q = 'UPDATE login SET company="'.$company.'", name="'.$name.'", username="'.$email.'", password="'.$pass_encrypted.'", s3_key="'.$aws_key.'" '.$aws_secret_query.', paypal="'.$paypal.'", timezone = "'.$timezone.'", language = "'.$language.'", ses_endpoint = "'.$ses_endpoint.'", brands_rows = '.$brands_rows.', strict_delete = '.$strict_delete.', dark_mode = '.$dark_mode.', dark_mode_shortcut = "'.$dark_mode_shortcut.'" WHERE id = '.$userID;
		else
			$q = 'UPDATE login SET company="'.$company.'", name="'.$name.'", username="'.$email.'", s3_key="'.$aws_key.'" '.$aws_secret_query.', paypal="'.$paypal.'", timezone = "'.$timezone.'", language = "'.$language.'", ses_endpoint = "'.$ses_endpoint.'", brands_rows = '.$brands_rows.', strict_delete = '.$strict_delete.', dark_mode = '.$dark_mode.', dark_mode_shortcut = "'.$dark_mode_shortcut.'" WHERE id = '.$userID;
		$r = mysqli_query($mysqli, $q);
		if ($r)
		{
			if($send_rate!='' && $ses_send_rate!='')
			{
				//Update send_rate in database
				mysqli_query($mysqli, 'UPDATE login SET send_rate = '.$send_rate);
			}
			
			echo true; 
		}
	}
	else
	{
		//If userID POSTed here isn't the userID this user logs in with, then exit.
		if($userID != get_app_info('userID')) exit;
		
		if($change_pass)
			$q = 'UPDATE login SET company="'.$company.'", name="'.$name.'", username="'.$email.'", password="'.$pass_encrypted.'", timezone = "'.$timezone.'", language = "'.$language.'", dark_mode = '.$dark_mode.', dark_mode_shortcut = "'.$dark_mode_shortcut.'" WHERE id = '.$userID;
		else
			$q = 'UPDATE login SET company="'.$company.'", name="'.$name.'", username="'.$email.'", timezone = "'.$timezone.'", language = "'.$language.'", dark_mode = '.$dark_mode.', dark_mode_shortcut = "'.$dark_mode_shortcut.'" WHERE id = '.$userID;
		$r = mysqli_query($mysqli, $q);
		if ($r)
		{
			if(!get_app_info('campaigns_only'))
				$additional_line1 = ', from_name = "'.$from_name.'", from_email = "'.$from_email.'", reply_to = "'.$reply_to.'", query_string = "'.$query_string.'"'.', test_email_prefix = "'.$test_email_prefix.'"';
			else
				$additional_line1 = '';
			
			if(!get_app_info('campaigns_only') || !get_app_info('reports_only') || !get_app_info('lists_only'))	
				$additional_line2 = ', campaign_report_rows = '.$campaign_report_rows.', templates_lists_sorting = "'.$templates_lists_sorting.'"';
			else
				$additional_line2 = '';
			
			if(!get_app_info('lists_only'))		
				$additional_line3 = ', gdpr_only = '.$gdpr_only.', gdpr_only_ar = '.$gdpr_only_ar.', gdpr_options = '.$gdpr_options.', recaptcha_sitekey = "'.$recaptcha_sitekey.'", recaptcha_secretkey = "'.$recaptcha_secretkey.'"';
			else	
				$additional_line3 = '';
			
			$additional_line4 = ', smtp_host = "'.$smtp_host.'", smtp_port = "'.$smtp_port.'", smtp_ssl = "'.$smtp_ssl.'", smtp_username = "'.$smtp_username.'" '.$smtp_password_line.' '.$openai_api_key_line.', ai_disabled = '.$ai_disabled.', opens_tracking = '.$opens_tracking.', links_tracking = '.$links_tracking;
			
		    //save sending app data
			$q2 = 'UPDATE apps SET app_name = "'.$company.'" '.$additional_line3.' '.$additional_line1.' '.$additional_line2.' '.$additional_line4.' WHERE id = '.get_app_info('restricted_to_app').' AND userID = '.get_app_info('main_userID');
			$r2 = mysqli_query($mysqli, $q2);
			if ($r2)
			{
			    echo true; 
			}
			else
			{
				error_log("[Can't save brand user settings]".mysqli_error($mysqli).': in '.__FILE__.' on line '.__LINE__);
			}
		}
		else
		{
			error_log("[Can't save brand user login settings]".mysqli_error($mysqli).': in '.__FILE__.' on line '.__LINE__);
		}
	} 
?>
