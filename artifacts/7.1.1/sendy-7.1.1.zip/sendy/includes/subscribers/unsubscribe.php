<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php include('../helpers/subscription.php');?>
<?php 
	$subscriber_id = isset($_POST['subscriber_id']) && is_numeric($_POST['subscriber_id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['subscriber_id']) : exit;
	$action = $_POST['action'];
	$time = time();
	$join_date = round($time/60)*60;
	
	if($action=='unsubscribe')
		$q = 'UPDATE subscribers SET unsubscribed = 1, timestamp = '.$time.' WHERE id = '.$subscriber_id.' AND userID = '.get_app_info('main_userID');
	else if($action=='resubscribe')
		$q = 'UPDATE subscribers SET unsubscribed = 0, timestamp = '.$time.' WHERE id = '.$subscriber_id.' AND userID = '.get_app_info('main_userID');
	else if($action=='confirm')
		$q = 'UPDATE subscribers SET confirmed = 1, timestamp = '.$time.', join_date = CASE WHEN join_date IS NULL THEN '.$join_date.' ELSE join_date END WHERE id = '.$subscriber_id.' AND userID = '.get_app_info('main_userID');
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
		if($action=='confirm')
		{
			$q = 'SELECT list FROM subscribers WHERE id = '.$subscriber_id.' AND userID = '.get_app_info('main_userID');
			$r = mysqli_query($mysqli, $q);
			if ($r && mysqli_num_rows($r) > 0)
			{
				while($row = mysqli_fetch_array($r)) update_segments(APP_PATH, $row['list']);
			}
		}
		echo true; 
	}
	
?>
