<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	$template_id = isset($_POST['template_id']) && is_numeric($_POST['template_id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['template_id']) : exit;

	$q = 'SELECT app, template_name FROM template WHERE id = '.$template_id.' AND userID = '.get_app_info('main_userID').' LIMIT 1';
	$r = mysqli_query($mysqli, $q);
	$template = $r && mysqli_num_rows($r) > 0 ? mysqli_fetch_array($r) : false;

	//delete list and its subscribers
	$q = 'DELETE FROM template WHERE id = '.$template_id.' AND userID = '.get_app_info('main_userID');
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
		$builtin_template_name = $template ? get_builtin_sample_template_name($template['template_name']) : '';
		if($builtin_template_name!='')
		{
			$template_name = mysqli_real_escape_string($mysqli, $builtin_template_name);
			$app_id = (int)$template['app'];
			mysqli_query($mysqli, 'INSERT IGNORE INTO template_deleted_builtins (userID, app, template_name, deleted) VALUES ('.get_app_info('main_userID').', '.$app_id.', "'.$template_name.'", '.time().')');
		}
		echo true;
	}
	else echo false;
?>
