<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//------------------------------------------------------//
	//                      	INIT                       //
	//------------------------------------------------------//
	
	$edit = isset($_GET['edit']) ? $_GET['edit'] : '';
	$template_id = isset($_GET['t']) && is_numeric($_GET['t']) ? mysqli_real_escape_string($mysqli, (int)$_GET['t']) : 0;
	$save_only = isset($_POST['save-only']) ? mysqli_real_escape_string($mysqli, $_POST['save-only']) : 0;	
	$template_name = addslashes(mysqli_real_escape_string($mysqli, $_POST['template_name']));
	$from_name = addslashes(mysqli_real_escape_string($mysqli, $_POST['from_name']));
	$from_email = addslashes(mysqli_real_escape_string($mysqli, $_POST['from_email']));
	$reply_to = addslashes(mysqli_real_escape_string($mysqli, $_POST['reply_to']));
	$html = trim($_POST['html'])=='<html><head></head><body></body></html>' ? '' : addslashes($_POST['html']);
	$plain = addslashes($_POST['plain']);
	$editor_mode = isset($_POST['editor_mode']) ? sanitize_editor_mode($_POST['editor_mode'], '') : '';
	$editor_project_data_post = isset($_POST['editor_project_data']) ? trim($_POST['editor_project_data']) : '';
	$w_clicked = isset($_POST['w_clicked']) ? $_POST['w_clicked'] : null;
	$current_html = '';
	$current_editor_mode = '';
	$current_editor_project_data = '';
	$editor_project_data = '';
	$redirect = ($save_only || $w_clicked) ? get_app_info('path').'/edit-template?i='.get_app_info('app').'&t='.$template_id : get_app_info('path').'/templates?i='.get_app_info('app');
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	if($edit)
	{
		$q = 'SELECT html_text, editor_mode, editor_project_data FROM template WHERE id='.$template_id.' AND userID = '.get_app_info('main_userID');
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
			while($row = mysqli_fetch_array($r))
			{
				$current_html = $row['html_text']=='' ? '' : stripslashes($row['html_text']);
				$current_editor_mode = $row['editor_mode']=='' ? '' : stripslashes($row['editor_mode']);
				$current_editor_project_data = $row['editor_project_data']=='' ? '' : $row['editor_project_data'];
			}
		}
	}
	
	if($editor_mode=='')
	{
		if($edit) $editor_mode = resolve_editor_mode($current_editor_mode, null, 'dragdrop');
		else $editor_mode = 'dragdrop';
	}
	
	if($editor_project_data_post!='')
		$editor_project_data = mysqli_real_escape_string($mysqli, $editor_project_data_post);
	else if($edit)
	{
		if($editor_mode=='dragdrop')
			$editor_project_data = '';
		else if($current_html === stripslashes($html) && $current_editor_project_data!='')
			$editor_project_data = mysqli_real_escape_string($mysqli, $current_editor_project_data);
	}
	
	if($edit)
	{
		$q = 'UPDATE template SET template_name="'.$template_name.'", from_name="'.$from_name.'", from_email="'.$from_email.'", reply_to="'.$reply_to.'", html_text="'.$html.'", plain_text="'.$plain.'", editor_mode="'.$editor_mode.'", editor_project_data="'.$editor_project_data.'" WHERE id='.$template_id;
		$r = mysqli_query($mysqli, $q);
		if ($r) 
		{
			if($save_only || $w_clicked) header('Location: '.get_app_info('path').'/edit-template?i='.get_app_info('app').'&t='.$template_id); 
			else header('Location: ' .get_app_info('path').'/templates?i='.get_app_info('app'));
		}
		else show_error(_('Unable to create template'), '<p>'.mysqli_error($mysqli).'</p>');	
	}
	else
	{	
		//Insert into campaigns
		$q = 'INSERT INTO template (userID, app, template_name, html_text, plain_text, from_name, from_email, reply_to, editor_mode, editor_project_data) VALUES ('.get_app_info('main_userID').', '.get_app_info('app').', "'.$template_name.'", "'.$html.'", "'.$plain.'", "'.$from_name.'", "'.$from_email.'", "'.$reply_to.'", "'.$editor_mode.'", "'.$editor_project_data.'")';
		$r = mysqli_query($mysqli, $q);
		if ($r) 
		{
			$template_id = mysqli_insert_id($mysqli);
			
			if($save_only || $w_clicked) header('Location: '.get_app_info('path').'/edit-template?i='.get_app_info('app').'&t='.$template_id); 
			else header('Location: ' .get_app_info('path').'/templates?i='.get_app_info('app'));
		}
		else show_error(_('Unable to create template'), '<p>'.mysqli_error($mysqli).'</p>');	
	}
?>
