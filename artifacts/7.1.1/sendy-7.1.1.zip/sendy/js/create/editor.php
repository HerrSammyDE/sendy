<script type="text/javascript">
	$(document).ready(function() {
		function getSourceEditorValue(editor) {
			var codeMirror = window["codemirror_" + editor.id];
			
			if (editor.mode === 'source') {
				if (codeMirror && typeof codeMirror.getValue === 'function') return codeMirror.getValue();
				
				var editable = editor.editable();
				if (editable && editable.$ && typeof editable.$.value === 'string') return editable.$.value;
			}
			
			return editor.getData();
		}
		
		function preserveSourceHtml(editor) {
			if (editor.mode !== 'source' || editor.checkDirty()) return;
			if (typeof editor._sendySourceHtml !== 'string') return;
			
			var codeMirror = window["codemirror_" + editor.id];
			if (codeMirror && typeof codeMirror.getValue === 'function') {
				if (codeMirror.getValue() !== editor._sendySourceHtml) {
					codeMirror.setValue(editor._sendySourceHtml);
					codeMirror.save();
				}
			} else {
				var editable = editor.editable();
				if (editable && editable.$ && editable.$.value !== editor._sendySourceHtml) editable.$.value = editor._sendySourceHtml;
			}
			
			editor.resetDirty();
		}
		
		function syncEditorValue(editor) {
			if (!editor || !editor.element) return '';
			
			var value = typeof editor._sendySourceHtml === 'string' ? editor._sendySourceHtml : '';
			
			if (editor.mode === 'source') {
				value = getSourceEditorValue(editor);
				editor._sendySourceHtml = value;
			} else if (editor.checkDirty()) {
				value = editor.getData();
			}
			
			$(editor.element.$).val(value);
			return value;
		}
		
		function bindSourcePreservation(editor) {
			editor._sendySourceHtml = $(editor.element.$).val() || '';
			
			editor.on('instanceReady', function() {
				editor.resetDirty();
			});
			
			editor.on('beforeModeUnload', function() {
				if (editor.mode === 'source') editor._sendySourceHtml = getSourceEditorValue(editor);
			});
			
			editor.on('mode', function() {
				preserveSourceHtml(editor);
			});
			
			$(editor.element.$).closest('form').off('submit.sendy-editor-sync').on('submit.sendy-editor-sync', function() {
				syncEditorValue(editor);
			});
			
			editor.syncSendyValue = function() {
				return syncEditorValue(editor);
			};
		}
		
		window.SendySyncHtmlEditor = function() {
			if (window.CKEDITOR && CKEDITOR.instances && CKEDITOR.instances.html && typeof CKEDITOR.instances.html.syncSendyValue === 'function') {
				return CKEDITOR.instances.html.syncSendyValue();
			}
			return '';
		};
		
		ckEditor = CKEDITOR.replace( 'html', {
			fullPage: true,
			allowedContent: true,
			autoUpdateElement: false,
			autoParagraph: false,
			fillEmptyBlocks: false,
			basicEntities: false,
			entities: false,
			entities_latin: false,
			entities_greek: false,
			forceSimpleAmpersand: true,
			filebrowserUploadUrl: 'includes/create/upload.php?app=<?php echo get_app_info('app');?>',
			height: '570px',
			extraPlugins: 'codemirror,dragresize'
			<?php if($dark_mode):?>
			,skin: 'moono-dark'
			<?php else:?>
			,uiColor: '#FFFFFF'
			<?php endif;?>
		});
		
		// wait until the editor is done initializing
		ckEditor.on("instanceReady",function() {
		  // overwrite the default save function
		  ckEditor.addCommand( "save", {
		    modes : { wysiwyg:1, source:1 },
		    exec : function () {
		      window.SendySyncHtmlEditor();
		      $('<input>').attr({type: 'hidden',id: 'save-only',name: 'save-only',value: 1}).appendTo('form');
		      $("#campaign-save-only-btn, #autoresponder-save-only-btn, #save-button").click();
		    }
		   });
		});
		
		bindSourcePreservation(ckEditor);
		
		//Save campaign only
		$("#campaign-save-only-btn, #autoresponder-save-only-btn").click(function(e){
	        e.preventDefault(); 
	    	window.SendySyncHtmlEditor();
	    	$('<input>').attr({type: 'hidden',id: 'save-only',name: 'save-only',value: 1}).appendTo('form');
			$("#edit-form").submit();
	    });
		
	});
</script>
