<link rel="stylesheet" href="<?php echo get_app_info('path');?>/js/grapesjs/grapes.min.css?11">
<link rel="stylesheet" href="<?php echo get_app_info('path');?>/css/grapesjs-sendy.css?11">
<script src="<?php echo get_app_info('path');?>/js/grapesjs/grapes.min.js?11"></script>
<script src="<?php echo get_app_info('path');?>/js/grapesjs/preset-newsletter/grapesjs-preset-newsletter.min.js?11"></script>
<script src="<?php echo get_app_info('path');?>/js/ckeditor/plugins/codemirror/js/beautify.min.js?11"></script>
<script type="text/javascript">
	$(document).ready(function() {
		SendyEditorModes.initGrapes({
			formSelector: '#edit-form',
			textareaSelector: '#html',
			projectInputSelector: '#editor_project_data',
			containerSelector: '#gjs',
			initialHtml: <?php echo json_encode(isset($grapesjs_initial_html) ? $grapesjs_initial_html : '');?>,
			projectData: <?php echo json_encode(isset($grapesjs_project_data) ? $grapesjs_project_data : null);?>,
			assetUploadUrl: <?php echo json_encode(get_app_info('path').'/includes/create/upload.php?app='.get_app_info('app').'&response=json');?>,
			saveOnlyButtonsSelector: <?php echo json_encode(isset($grapesjs_save_only_selector) ? $grapesjs_save_only_selector : '');?>,
			assetUploadError: <?php echo json_encode(_('Unable to upload image. Please try again later.'));?>
		});
	});
</script>
