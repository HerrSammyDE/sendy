/*!
 * Legacy compatibility helpers for jQuery 4 upgrades.
 * Keep this narrow and remove entries as bundled plugins are modernized.
 */
(function ($) {
	"use strict";

	var class2type = {};
	var toString = class2type.toString;
	var userAgent = window.navigator.userAgent;

	"Boolean Number String Function Array Date RegExp Object Error Symbol".split(" ").forEach(function (name) {
		class2type["[object " + name + "]"] = name.toLowerCase();
	});

	if (!$.camelCase) {
		$.camelCase = function (value) {
			return (value || "").replace(/^-ms-/, "ms-").replace(/-([a-z])/g, function (_, letter) {
				return letter.toUpperCase();
			});
		};
	}

	if (!$.isArray) {
		$.isArray = Array.isArray;
	}

	if (!$.isFunction) {
		$.isFunction = function (value) {
			return typeof value === "function";
		};
	}

	if (!$.isNumeric) {
		$.isNumeric = function (value) {
			var type = $.type(value);

			return (type === "number" || type === "string") && !isNaN(value - parseFloat(value));
		};
	}

	if (!$.isWindow) {
		$.isWindow = function (value) {
			return value != null && value === value.window;
		};
	}

	if (!$.nodeName) {
		$.nodeName = function (elem, name) {
			return !!(elem && elem.nodeName) && elem.nodeName.toLowerCase() === name.toLowerCase();
		};
	}

	if (!$.now) {
		$.now = Date.now;
	}

	if (!$.parseJSON) {
		$.parseJSON = JSON.parse;
	}

	if (!$.trim) {
		$.trim = function (value) {
			return value == null ? "" : String(value).trim();
		};
	}

	if (!$.type) {
		$.type = function (value) {
			if (value == null) {
				return String(value);
			}

			return typeof value === "object" || typeof value === "function" ?
				class2type[toString.call(value)] || "object" :
				typeof value;
		};
	}

	if (!$.unique && $.uniqueSort) {
		$.unique = $.uniqueSort;
	}

	if (!$.fn.andSelf && $.fn.addBack) {
		$.fn.andSelf = $.fn.addBack;
	}

	if (!$.fn.size) {
		$.fn.size = function () {
			return this.length;
		};
	}

	if (!$.fn.push) {
		$.fn.push = Array.prototype.push;
		$.fn.sort = Array.prototype.sort;
		$.fn.splice = Array.prototype.splice;
	}

	if (!$.browser) {
		$.browser = {};
	}

	if (typeof $.browser.msie === "undefined") {
		$.browser.msie = /MSIE |Trident\//.test(userAgent);
	}

	if (typeof $.browser.webkit === "undefined") {
		$.browser.webkit = /AppleWebKit\//.test(userAgent);
	}

	if (typeof $.browser.mozilla === "undefined") {
		$.browser.mozilla = /Firefox\//.test(userAgent);
	}

	if (typeof $.browser.safari === "undefined") {
		$.browser.safari = /Safari\//.test(userAgent) && !/Chrome\/|Chromium\/|Edg\//.test(userAgent);
	}

	if (typeof $.browser.opera === "undefined") {
		$.browser.opera = /Opera|OPR\//.test(userAgent);
	}
}(jQuery));
