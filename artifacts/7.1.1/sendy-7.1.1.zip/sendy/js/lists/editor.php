<script type="text/javascript">
	$(document).ready(function() {
		function getSourceEditorValue(editor) {
			var codeMirror = window["codemirror_" + editor.id];
			
			if (editor.mode === 'source') {
				if (codeMirror && typeof codeMirror.getValue === 'function') return codeMirror.getValue();
				
				var editable = editor.editable();
				if (editable && editable.$ && typeof editable.$.value === 'string') return editable.$.value;
			}
			
			return editor.getData();
		}
		
		function preserveSourceHtml(editor) {
			if (editor.mode !== 'source' || editor.checkDirty()) return;
			if (typeof editor._sendySourceHtml !== 'string') return;
			
			var codeMirror = window["codemirror_" + editor.id];
			if (codeMirror && typeof codeMirror.getValue === 'function') {
				if (codeMirror.getValue() !== editor._sendySourceHtml) {
					codeMirror.setValue(editor._sendySourceHtml);
					codeMirror.save();
				}
			} else {
				var editable = editor.editable();
				if (editable && editable.$ && editable.$.value !== editor._sendySourceHtml) editable.$.value = editor._sendySourceHtml;
			}
			
			editor.resetDirty();
		}
		
		function syncEditorValue(editor) {
			if (!editor || !editor.element) return '';
			
			var value = typeof editor._sendySourceHtml === 'string' ? editor._sendySourceHtml : '';
			
			if (editor.mode === 'source') {
				value = getSourceEditorValue(editor);
				editor._sendySourceHtml = value;
			} else if (editor.checkDirty()) {
				value = editor.getData();
			}
			
			$(editor.element.$).val(value);
			return value;
		}
		
		function bindSourcePreservation(editor) {
			editor._sendySourceHtml = $(editor.element.$).val() || '';
			
			editor.on('instanceReady', function() {
				editor.resetDirty();
			});
			
			editor.on('beforeModeUnload', function() {
				if (editor.mode === 'source') editor._sendySourceHtml = getSourceEditorValue(editor);
			});
			
			editor.on('mode', function() {
				preserveSourceHtml(editor);
			});
			
			$(editor.element.$).closest('form').off('submit.sendy-editor-sync-' + editor.name).on('submit.sendy-editor-sync-' + editor.name, function() {
				syncEditorValue(editor);
			});
		}
		
		var thankyouEditor = CKEDITOR.replace( 'thankyou_message', {
			fullPage: true,
			allowedContent: true,
			autoUpdateElement: false,
			autoParagraph: false,
			fillEmptyBlocks: false,
			basicEntities: false,
			entities: false,
			entities_latin: false,
			entities_greek: false,
			forceSimpleAmpersand: true,
			filebrowserUploadUrl: 'includes/create/upload.php?app=<?php echo get_app_info('app');?>',
			height: '350px',
			extraPlugins: 'codemirror'
			<?php if($dark_mode):?>
			,skin: 'moono-dark'
			<?php else:?>
			,uiColor: '#FFFFFF'
			<?php endif;?>
			
		});
		var goodbyeEditor = CKEDITOR.replace( 'goodbye_message', {
			fullPage: true,
			allowedContent: true,
			autoUpdateElement: false,
			autoParagraph: false,
			fillEmptyBlocks: false,
			basicEntities: false,
			entities: false,
			entities_latin: false,
			entities_greek: false,
			forceSimpleAmpersand: true,
			filebrowserUploadUrl: 'includes/create/upload.php?app=<?php echo get_app_info('app');?>',
			height: '350px',
			extraPlugins: 'codemirror'
			<?php if($dark_mode):?>
			,skin: 'moono-dark'
			<?php else:?>
			,uiColor: '#FFFFFF'
			<?php endif;?>
		});
		var confirmationEditor = CKEDITOR.replace( 'confirmation_email', {
			fullPage: true,
			allowedContent: true,
			autoUpdateElement: false,
			autoParagraph: false,
			fillEmptyBlocks: false,
			basicEntities: false,
			entities: false,
			entities_latin: false,
			entities_greek: false,
			forceSimpleAmpersand: true,
			filebrowserUploadUrl: 'includes/create/upload.php?app=<?php echo get_app_info('app');?>',
			height: '350px',
			extraPlugins: 'codemirror'
			<?php if($dark_mode):?>
			,skin: 'moono-dark'
			<?php else:?>
			,uiColor: '#FFFFFF'
			<?php endif;?>
		});
		
		bindSourcePreservation(thankyouEditor);
		bindSourcePreservation(goodbyeEditor);
		bindSourcePreservation(confirmationEditor);
	});
</script>
