<?php include('includes/header.php');?>
<?php include('includes/login/auth.php');?>
<?php include('includes/templates/main.php');?>
<?php
	if(get_app_info('is_sub_user')) 
	{
		if(get_app_info('app')!=get_app_info('restricted_to_app'))
		{
			echo '<script type="text/javascript">window.location="'.addslashes(get_app_info('path')).'/templates?i='.get_app_info('restricted_to_app').'"</script>';
			exit;
		}
		else if(get_app_info('campaigns_only')==1 && get_app_info('templates_only')==1 && get_app_info('lists_only')==1 && get_app_info('reports_only')==1)
		{
			echo '<script type="text/javascript">window.location="'.addslashes(get_app_info('path')).'/logout"</script>';
			exit;
		}
		else if(get_app_info('templates_only')==1)
		{
			go_to_next_allowed_section();
		}
	}
?>
<div class="row-fluid">
    <div class="span2">
        <?php include('includes/sidebar.php');?>
    </div> 
    <div class="span10">
    	<div>
	    	<p class="lead">
	    	<?php echo sendy_brand_logo_img();?>
		    	<?php if(get_app_info('is_sub_user')):?>
			    	<?php echo get_app_data('app_name');?>
		    	<?php else:?>
			    	<a href="<?php echo get_app_info('path'); ?>/edit-brand?i=<?php echo get_app_info('app');?>" data-placement="right" title="<?php echo _('Edit brand settings');?>"><?php echo get_app_data('app_name');?> <span class="icon icon-pencil top-brand-pencil"></span></a>
		    	<?php endif;?>
		    </p>
    	</div>
    	<h2><?php echo _('All templates');?></h2><br/>
    	<div style="clear:both;">
    		<div class="dropdown" style="float:left; margin: 0 0 30px 0;" id="templates-new-template-dropdown">
    			<button class="btn dropdown-toggle new-campaign-toggle" type="button" data-toggle="dropdown"><i class="icon-plus-sign"></i> <span class="new-campaign-label"><?php echo _('Create a new template');?></span>
    			<span class="caret"></span></button>
    			<?php sendy_render_new_campaign_dropdown_menu('dropdown-menu', sendy_get_new_template_dropdown_options());?>
    		</div>
    	</div>
    	
    	<br style="clear:both;"/>
    	
	    <table class="table table-striped responsive" style="margin-top:0;">
		  <thead>
		    <tr>
		      <th><?php echo _('Template name');?></th>
		      <th><?php echo _('Preview');?></th>
		      <?php if(!get_app_info('is_sub_user') || (get_app_info('is_sub_user') && get_app_info('campaigns_only')==0)):?>
			      <th><?php echo _('Use');?></th>
		      <?php endif;?>
		      <th><?php echo _('Duplicate');?></th>
		      <th><?php echo _('Edit');?></th>
		      <th><?php echo _('Delete');?></th>
		    </tr>
		  </thead>
		  <tbody>
			  
		  	<?php 
			  	//Get sorting preference
			  	$q = 'SELECT templates_lists_sorting FROM apps WHERE id = '.get_app_info('app');
			  	$r = mysqli_query($mysqli, $q);
			  	if ($r && mysqli_num_rows($r) > 0) while($row = mysqli_fetch_array($r)) $templates_lists_sorting = $row['templates_lists_sorting'];
			  	$sortby = $templates_lists_sorting=='date' ? 'id DESC' : 'template_name ASC';
		  	?>
			  
		  	<?php 
				$limit = get_app_data('campaign_report_rows');
				$total_subs = totals(get_app_info('app'));
				$total_pages = ceil($total_subs/$limit);
				$p = sendy_current_page($total_pages);
				$offset = ($p-1) * $limit;

			  	$q = 'SELECT id, template_name FROM template WHERE userID = '.get_app_info('main_userID').' AND app='.get_app_info('app').' ORDER BY '.$sortby.' LIMIT '.$offset.','.$limit;
			  	$r = mysqli_query($mysqli, $q);
			  	if ($r && mysqli_num_rows($r) > 0)
			  	{
			  	    while($row = mysqli_fetch_array($r))
			  	    {
			  			$id = $row['id'];
			  			$template_name = stripslashes($row['template_name']);
			  			
			  			echo '
					  		<tr id="'.$id.'">
						      <td><a href="edit-template?i='.get_app_info('app').'&t='.$id.'" title=""><i class="icon icon-file-text-alt" style="margin-right:5px;"></i> '.$template_name.'</a></td>
						      <td><a href="'.get_app_info('path').'/template-preview?t='.$id.'" title="" id="preview-btn-'.$id.'" class="iframe-preview"><i class="icon icon-eye-open"></i></a></td>
						      ';
						if(!get_app_info('is_sub_user') || (get_app_info('is_sub_user') && get_app_info('campaigns_only')==0))
						echo '<td><a href="includes/templates/use-template.php?i='.get_app_info('app').'&t='.$id.'" title="'._('Create a new campaign with this template').'"><i class="icon icon-edit"></i></a></td>'; 
						
						echo '<td>';
						if(get_app_info('is_sub_user'))
						{
						    echo '
						    <form action="'.get_app_info('path').'/includes/templates/duplicate.php" method="POST" accept-charset="utf-8" class="form-vertical" name="duplicate-form" id="duplicate-form-direct-'.$id.'" style="margin-bottom:0px;">
						    <input type="hidden" name="template_id" value="'.$id.'"/>
						    <input type="hidden" name="on-brand" value="'.get_app_info('app').'"/>
						    <a href="javascript:void(0)" id="duplicate-btn-direct-'.$id.'"><i class="icon icon-copy"></i></a>
						    <script type="text/javascript">
						    $("#duplicate-btn-direct-'.$id.'").click(function(){
						    	$("#duplicate-form-direct-'.$id.'").submit();
						    });
						    </script>
						    </form>
						    ';
						}
						else
						    echo '<a href="#duplicate-modal" title="" id="duplicate-btn-'.$id.'" data-toggle="modal" data-tid="'.$id.'" class="duplicate-btn"><i class="icon icon-copy"></i></a>';
						echo '</td>';
						
						echo '
						      <td><a href="edit-template?i='.get_app_info('app').'&t='.$id.'" title=""><i class="icon icon-pencil"></i></a></td>
						      <td><a href="#delete-template" title="'._('Delete').' '.$template_name.'" id="delete-btn-'.$id.'" data-toggle="modal"><span class="icon icon-trash"></span></a></td>
					      <script type="text/javascript">
					        $("#delete-btn-'.$id.'").click(function(e){
								e.preventDefault(); 
								$("#delete-template-btn").attr("data-id", '.$id.');
								$("#template-to-delete").text("'.$template_name.'");
								$("#delete-text").val("");
							});
							</script>						  
						    </tr>
					  	';
			  	    }  
			  	}
			  	else
			  	{
			  		$empty_colspan = (!get_app_info('is_sub_user') || (get_app_info('is_sub_user') && get_app_info('campaigns_only')==0)) ? 6 : 5;
				  	echo '
				  		<tr>
					      <td colspan="'.$empty_colspan.'">'._('No templates have been created yet').'. <a href="'.get_app_info('path').'/create-template?i='.get_app_info('app').'" title="" style="text-decoration: underline;">'._('Create one').'</a>!</td>
					    </tr>
				  	';
			  	}
		  	?>
		    
		  </tbody>
		</table>
		
		<div id="duplicate-modal" class="modal hide fade">
		    <div class="modal-header">
		      <button type="button" class="close" data-dismiss="modal">&times;</button>
		      <h3><?php echo _('Duplicate on which brand?');?></h3>
		    </div>
		    <div class="modal-body">
		    	<form action="<?php echo get_app_info('path')?>/includes/templates/duplicate.php" method="POST" accept-charset="utf-8" class="form-vertical" name="duplicate-form" id="duplicate-form">
		    	<div class="control-group">
		            <label class="control-label" for="on-brand"><?php echo _('Choose a brand you\'d like to duplicate this template on');?>:</label><br/>
		            <div class="controls">
		              <select id="on-brand" name="on-brand">
		              	<?php 
		              		echo '<option value="'.get_app_info('app').'" id="brand-'.get_app_info('app').'">'.get_app_data('app_name').'</option>';
		              	
			              	$q = 'SELECT id, app_name FROM apps WHERE userID = '.get_app_info('main_userID');
			              	$r = mysqli_query($mysqli, $q);
			              	if ($r && mysqli_num_rows($r) > 0)
			              	{
			              	    while($row = mysqli_fetch_array($r))
			              	    {
			              	    	$app_id = $row['id'];
			              			$app_name = $row['app_name'];
			              			
			              			if($app_id != get_app_info('app'))
				              			echo '<option value="'.$app_id.'" id="brand-'.$app_id.'">'.$app_name.'</option>';
			              	    }  
			              	}
		              	?>
		              </select>
		              <input type="hidden" name="template_id" id="template_id" value=""></input>
		            </div>
		          </div>
		          </form>
		    </div>
		    <div class="modal-footer">
		      <a href="#" class="btn btn" data-dismiss="modal"><?php echo _('Cancel');?></a>
		      <a href="javascript:void(0)" class="btn btn-inverse" id="duplicate-btn"><?php echo _('Duplicate');?></a>
		    </div>
	    
		    <script type="text/javascript">
			    $(".duplicate-btn").click(function(){
				    tid = $(this).data("tid");
				    $("#template_id").val(tid);
			    });
			    $("#duplicate-btn").click(function(){
				    $("#duplicate-form").submit();
			    });
		    </script>
		</div>
		
		<!-- Delete -->
		<div id="delete-template" class="modal hide fade">
		  <div class="modal-header">
		    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		    <h3><?php echo _('Delete template');?></h3>
		  </div>
		  <div class="modal-body">
		    <p><?php echo _('This template will be permanently deleted. Confirm delete <span id="template-to-delete" style="font-weight:bold;"></span>?');?></p>
		  </div>
		  <div class="modal-footer">
			<?php if(get_app_info('strict_delete')):?>
			<input autocomplete="off" type="text" class="input-large" id="delete-text" name="delete-text" placeholder="<?php echo _('Type the word');?> DELETE" style="margin: -2px 7px 0 0;"/>
			<?php endif;?>
			
		    <a href="javascript:void(0)" id="delete-template-btn" data-id="" class="btn btn-primary"><?php echo _('Delete');?></a>
		  </div>
		</div>
		
		<script type="text/javascript">
			$("#delete-template-btn").click(function(e){
				e.preventDefault(); 
				
				<?php if(get_app_info('strict_delete')):?>
				if($("#delete-text").val()=='DELETE'){
				<?php endif;?>
				
					$.post("includes/templates/delete.php", { template_id: $(this).attr("data-id") },
					  function(data) {
					      if(data)
					      {
					        $("#delete-template").modal('hide');
					        $("#"+$("#delete-template-btn").attr("data-id")).fadeOut(); 
					      }
					      else alert("<?php echo _('Sorry, unable to delete. Please try again later!')?>");
					  }
					);
				
				<?php if(get_app_info('strict_delete')):?>
				}
				else alert("<?php echo _('Type the word');?> DELETE");
				<?php endif;?>
			});
		</script>
		
		<link rel="stylesheet" type="text/css" href="<?php echo get_app_info('path');?>/css/print.css" media="print" />
		<script type="text/javascript" src="<?php echo get_app_info('path')?>/js/fancybox/jquery.fancybox.js"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo get_app_info('path')?>/js/fancybox/jquery.fancybox.css" media="screen" />
		<script type="text/javascript">
			$(document).ready(function() {		
				//iframe preview
				$(".iframe-preview").click(function(e) {
					e.preventDefault();
					
					$.fancybox.open({
						src : $(this).attr("href"),
						type : 'iframe',
						padding : 0,
						iframe : {
							preload : false
						}
					});
				});
			});
		</script>
		
		<?php pagination($limit); ?>
		
    </div>   
</div>
<?php include('includes/footer.php');?>
